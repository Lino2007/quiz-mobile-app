package ba.unsa.etf.rma.ba.unsa.etf.fragmenti;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class RangLista extends Fragment {

    private TextView etNazivIgracasaProcentom;
    private TextView etPozicija;
    private ListView RangLista;
    private ArrayList<String> lista = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    public RangLista() {}

    public interface OnItemClick {void onItemClicked(int pos);}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View vi = inflater.inflate(R.layout.ranglista_frag, container, false);
        etNazivIgracasaProcentom = vi.findViewById(R.id.etNazivIgraca);
        etPozicija = vi.findViewById(R.id.etPozicija);
        RangLista = vi.findViewById(R.id.lvRangLista);
        adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, lista);
        return vi;
    }



}
