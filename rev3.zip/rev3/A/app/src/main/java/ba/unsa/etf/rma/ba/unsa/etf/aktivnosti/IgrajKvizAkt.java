package ba.unsa.etf.rma.ba.unsa.etf.aktivnosti;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.ba.unsa.etf.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.ba.unsa.etf.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.ba.unsa.etf.klase.Kviz;
import ba.unsa.etf.rma.ba.unsa.etf.klase.Pitanje;


public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.OnItemClick {
    public static Kviz k;
    public static int brojTacnihOdgovora = 0;
    public static int brojPreostalihPitanja = 0;
    public static double procenatTacnih = 0;
    public static int brojacPitanja = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);
        k = (Kviz) getIntent().getSerializableExtra("kvizkojiseigra");
        ArrayList<Pitanje> listaPitanjaKviza = new ArrayList<>();
        if (k.getPitanja().size() != 0) {
            brojPreostalihPitanja = k.getPitanja().size();
            listaPitanjaKviza = k.getPitanja();
        }
        else
            Toast.makeText(this, "Nema dodanih pitanja za ovaj kviz!", Toast.LENGTH_SHORT).show();
        Collections.shuffle(listaPitanjaKviza);
        k.setPitanja(listaPitanjaKviza);

        Configuration config = getResources().getConfiguration();
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fm.beginTransaction();

        Bundle b = new Bundle();
        b.putSerializable("trenutnikviz",k);
        b.putSerializable("pitanjaizkviza", k.getPitanja());

        InformacijeFrag informacijeFrag = new InformacijeFrag();
        PitanjeFrag pitanjeFrag = new PitanjeFrag();
        //informacije
        fragmentTransaction.add(R.id.informacijePlace, informacijeFrag);
        informacijeFrag.setArguments(b);

        //pitanja
        fragmentTransaction.add(R.id.pitanjePlace, pitanjeFrag);
        pitanjeFrag.setArguments(b);

        fragmentTransaction.commit();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if (resultCode == RESULT_OK)
                super.onActivityResult(requestCode, resultCode, data);
        }
    }

    //kliknuto na neki odgovor
    @Override
    public void onItemClicked(final int pos) {
        Handler h = new Handler();
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                k = (Kviz) getIntent().getSerializableExtra("kvizkojiseigra");

                Configuration config = getResources().getConfiguration();
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fm.beginTransaction();

                Bundle b = new Bundle();
                b.putSerializable("trenutnikviz", k);
                b.putSerializable("pitanjaizkviza", k.getPitanja());

                InformacijeFrag informacijeFrag = new InformacijeFrag();
                PitanjeFrag pitanjeFrag = new PitanjeFrag();

                fragmentTransaction.replace(R.id.informacijePlace, informacijeFrag);
                fragmentTransaction.replace(R.id.pitanjePlace, pitanjeFrag);

                informacijeFrag.setArguments(b);
                pitanjeFrag.setArguments(b);

                brojacPitanja++;
                brojPreostalihPitanja = k.getPitanja().size() - brojacPitanja;
                if (brojacPitanja == 0)
                    procenatTacnih = 0;
                else
                    procenatTacnih = (double) brojTacnihOdgovora / brojacPitanja;
                fragmentTransaction.commit();
            }
        }, 2000);
    }
}
