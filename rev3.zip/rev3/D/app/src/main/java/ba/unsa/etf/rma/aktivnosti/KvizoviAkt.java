package ba.unsa.etf.rma.aktivnosti;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;

import java.io.Serializable;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.KategorijeAdapter;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.KvizoviAdapter;
import ba.unsa.etf.rma.resultreceiveri.UcitavanjeKategorijaReceiver;
import ba.unsa.etf.rma.resultreceiveri.UcitavanjeKvizovaPoKategorijiReceiver;
import ba.unsa.etf.rma.resultreceiveri.UcitavanjeKvizovaReceiver;
import ba.unsa.etf.rma.servisi.UcitavanjeKategorijaService;
import ba.unsa.etf.rma.servisi.UcitavanjeKvizovaPoKategorijiService;
import ba.unsa.etf.rma.servisi.UcitavanjeKvizovaService;

public class KvizoviAkt extends AppCompatActivity implements ListaFrag.OnItemClick, DetailFrag.OnItemClick,
        UcitavanjeKvizovaReceiver.Receiver, UcitavanjeKategorijaReceiver.Receiver, UcitavanjeKvizovaPoKategorijiReceiver.Receiver {

    private boolean ekranSiriOd550dp;
    private String nazivIzabraneKategorije = "";
    private ArrayList<Kategorija> listaPostojecihKategorija = new ArrayList<>();
    private ArrayList<Kviz> listaPostojecihKvizova = new ArrayList<>();
    private ArrayList<Kviz> listaPrikazanihKvizova = new ArrayList<>();
    private Spinner spPostojeceKategorije;
    private ListView lvKvizovi;
    private View footerDodajKviz;
    private KvizoviAdapter kvizoviAdapter;
    private BaseAdapter kategorijeAdapter;
    private FragmentManager fragmentManager;
    private ListaFrag listaFrag;
    private DetailFrag detailFrag;
    private boolean prvoPrikazivanje = true;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        prvoPrikazivanje = true;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.kvizovi_akt);
        progressDialog = new ProgressDialog(KvizoviAkt.this);

        Log.d("statt", "oncreate pozvan");
        Log.d("statt", String.valueOf(prvoPrikazivanje));

        // Na osnovu sirine ekrana se zakljucuje kakav layout prikazati

        utvrdiSirinuEkrana();
        postaviEkranNaOsnovuSirine();
    }

    private void utvrdiSirinuEkrana() {
        FrameLayout frameLayoutIzEkrana550dp = (FrameLayout) findViewById(R.id.listPlace);
        if (frameLayoutIzEkrana550dp == null) ekranSiriOd550dp = false;
        else ekranSiriOd550dp = true;
    }

    private void postaviEkranNaOsnovuSirine() {
        if (!ekranSiriOd550dp) inicijalizirajEkran();
        else inicijalizirajEkranW550dp();

    }

    private void inicijalizirajEkran() {
        dobaviWidgete();
        postaviFooterNaListuKvizova();
        inicijalizirajKategorije();
        postaviAdaptere();
        postaviListenerZaSkrolanjeListeKvizova();
        postaviListenerNaKategoriju();
        postaviListenerNaDugiKlikNaKviz();
        postaviListenerNaObicniKlikNaKviz();
        postaviListenerNaFooterDodavanjeKviza();
    }

    private void inicijalizirajEkranW550dp() {
        inicijalizirajKategorije();
        inicijalizirajFragmentManager();
        postaviFragmentLista();
        postaviFragmentDetail();
    }

    private void inicijalizirajFragmentManager() {
        fragmentManager = getSupportFragmentManager();
    }

    private void postaviFragmentLista() {
        FrameLayout listPlace = (FrameLayout) findViewById(R.id.listPlace);
        if (listPlace != null) {
            listaFrag = (ListaFrag) fragmentManager.findFragmentById(R.id.listPlace);
            if (listaFrag == null) {
                listaFrag = new ListaFrag();
                Bundle argumentiFragmentaLista = new Bundle();
                argumentiFragmentaLista.putParcelableArrayList("bundleListaKategorija", listaPostojecihKategorija);
                listaFrag.setArguments(argumentiFragmentaLista);
                fragmentManager.beginTransaction().replace(R.id.listPlace, listaFrag).commit();
            }
        }
    }

    private void postaviFragmentDetail() {
        FrameLayout detailPlace = (FrameLayout) findViewById(R.id.detailPlace);
        if (detailPlace != null) {
            detailFrag = (DetailFrag) fragmentManager.findFragmentById(R.id.detailPlace);
            if (detailFrag == null) {
                detailFrag = new DetailFrag();
                Bundle argumentiFragmentaDetail = new Bundle();
                argumentiFragmentaDetail.putParcelableArrayList("bundleListaPrikazanihKvizova", listaPrikazanihKvizova);
                detailFrag.setArguments(argumentiFragmentaDetail);
                fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
            }
        }
    }

    private void dobaviWidgete() {
        spPostojeceKategorije = (Spinner) findViewById(R.id.spPostojeceKategorije);
        lvKvizovi = (ListView) findViewById(R.id.lvKvizovi);
        footerDodajKviz = ((LayoutInflater) KvizoviAkt.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.footer_dodaj_kviz, null, false);
    }

    private void postaviFooterNaListuKvizova() {

        // Dodatni element liste kvizova, koji sluzi za pokretanje dodavanja novog kviza

        lvKvizovi.addFooterView(footerDodajKviz);
    }

    private void inicijalizirajKategorije() {
        if (!progressDialog.isShowing()) {
            progressDialog.setMessage("Ucitavanje...");
            progressDialog.show();
        }
        listaPostojecihKategorija = new ArrayList<>();
        Kategorija kategorijaSvi = new Kategorija();

        // Univerzalna kategorija "Svi" koja sluzi za prikaz svih kvizova, pa i onih koji nemaju kategoriju

        kategorijaSvi.setNaziv(getResources().getString(R.string.specijalna_kategorija_svi));
        kategorijaSvi.setId("976");
        kategorijaSvi.setIdIzFirebasea("ktgrjSvi");
        listaPostojecihKategorija.add(kategorijaSvi);
        ucitajKategorijeIzFireBaseaIOsvjeziEkran();
    }

    private void inicijalizirajKvizove() {
        listaPostojecihKvizova = new ArrayList<>();
        listaPrikazanihKvizova = new ArrayList<>();
        ucitajKvizoveIzFirebaseaIOsvjeziEkran();
    }

    private void postaviAdaptere() {
        kategorijeAdapter = new KategorijeAdapter(this, listaPostojecihKategorija, getResources());
        spPostojeceKategorije.setAdapter(kategorijeAdapter);
        kvizoviAdapter = new KvizoviAdapter(this, listaPrikazanihKvizova, getResources());
        lvKvizovi.setAdapter(kvizoviAdapter);
    }

    private void postaviListenerZaSkrolanjeListeKvizova() {
        lvKvizovi.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });
    }

    private void postaviListenerNaKategoriju() {
        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d("statt", "selected");
                if (!prvoPrikazivanje) {
                    if (position == 0) {

                        // Ako je kliknuto na kategoriju "Svi" prikazuju se svi kvizovi
                        Log.d("statt", "pozvan selection 0");
                        listaPostojecihKvizova = new ArrayList<>();
                        listaPrikazanihKvizova = new ArrayList<>();
                        if (!progressDialog.isShowing()) {
                            progressDialog.setMessage("Ucitavanje...");
                            progressDialog.show();
                        }
                        ucitajKvizoveIzFirebaseaIOsvjeziEkran();
                    }
                    else {

                        // Inace, prikazuju se samo kvizovi iz odabrane kategorije
                        Log.d("statt", "pozvan selection nije 0");
                        listaPostojecihKvizova =  new ArrayList<>();
                        listaPrikazanihKvizova = new ArrayList<>();
                        if (!progressDialog.isShowing()) {
                            progressDialog.setMessage("Ucitavanje...");
                            progressDialog.show();
                        }
                        ucitajKvizoveIzFirebaseaPoKategorijiIOsvjeziEkran(listaPostojecihKategorija.get(position).getIdIzFirebasea());
                    }
                }
                if (prvoPrikazivanje) prvoPrikazivanje = false;
                nazivIzabraneKategorije = listaPostojecihKategorija.get(position).getNaziv();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Log.d("statt", "nothing");
                //spPostojeceKategorije.setSelection(0);
                nazivIzabraneKategorije = listaPostojecihKategorija.get(0).getNaziv();
            }
        });
    }

    private void osvjeziPrikazKvizova() {
        BaseAdapter noviAdapter = new KvizoviAdapter(this, listaPrikazanihKvizova, getResources());
        lvKvizovi.setAdapter(noviAdapter);
    }

    private void ucitajKvizoveIzFirebaseaPoKategorijiIOsvjeziEkran(String idDokumentaKategorije) {
        UcitavanjeKvizovaPoKategorijiReceiver ucitavanjeKvizovaPoKategorijiReceiver = new UcitavanjeKvizovaPoKategorijiReceiver(new Handler());
        ucitavanjeKvizovaPoKategorijiReceiver.setReceiver(this);
        Intent intent = new Intent(this, UcitavanjeKvizovaPoKategorijiService.class);
        intent.putExtra("extraUcitavanjeKvizovaPoKategorijiReceiver", ucitavanjeKvizovaPoKategorijiReceiver);
        intent.putExtra("extraIdZadaneKategorijeIzFirebasea", idDokumentaKategorije);
        startService(intent);
    }

    private void postaviListenerNaDugiKlikNaKviz() {
        lvKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentUredjivanjeKviza = new Intent(KvizoviAkt.this, DodajKvizAkt.class);

                /* Preko booleana "extraDodavanjeNovogKviza" salje se informacija aktivnosti
                DodajKvizAkt da li se treba uredjivati postojeci kviz ili dodavati novi, a u ovom
                slucaju kliknuto je na postojeci kviz, tako da se ne dodaje novi nego uredjuje postojeci */

                intentUredjivanjeKviza.putExtra("extraDodavanjeNovogKviza", false);
                Kviz kvizZaUredjivanje = listaPrikazanihKvizova.get(position);

                // Aktivnosti DodajKvizAkt salju se postojeci podaci o kvizu za uredjivanje

                intentUredjivanjeKviza.putExtra("extraKvizZaUredjivanje", (Serializable) kvizZaUredjivanje);
                intentUredjivanjeKviza.putExtra("extraPozicijaKvizaUListi", position);
                intentUredjivanjeKviza.putParcelableArrayListExtra("extraListaKategorija",
                        listaPostojecihKategorija);

                /* Aktivnosti DodajKvizAkt salje se i lista svih ostalih kvizova da bi se moglo zabraniti
                ime kviza koje vec postoji, jer je ime kviza jedinstveno */

                ArrayList<Kviz> listaOstalihKvizova = new ArrayList<>();
                for (Kviz kviz : listaPostojecihKvizova) {
                    if (!kviz.getNaziv().equals(kvizZaUredjivanje.getNaziv())) {
                        listaOstalihKvizova.add(kviz);
                    }
                }
                intentUredjivanjeKviza.putParcelableArrayListExtra("extraListaDosadasnjihKvizova", listaOstalihKvizova);
                startActivityForResult(intentUredjivanjeKviza, 2);
                return true;
            }
        });
    }

    private void postaviListenerNaObicniKlikNaKviz() {
        lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intentIgranjeKviza = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                Kviz kvizZaIgranje = listaPrikazanihKvizova.get(position);

                // Aktivnosti IgrajKvizAkt salju se postojeci podaci o kvizu za igranje

                intentIgranjeKviza.putExtra("extraKvizZaIgranje", (Serializable) kvizZaIgranje);
                startActivityForResult(intentIgranjeKviza, 6);
            }
        });
    }

    private void postaviListenerNaFooterDodavanjeKviza() {
        footerDodajKviz.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent intentDodavanjeKviza = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                intentDodavanjeKviza.putExtra("extraDodavanjeNovogKviza",
                        true);
                intentDodavanjeKviza.putParcelableArrayListExtra("extraListaKategorija",
                        listaPostojecihKategorija);
                intentDodavanjeKviza.putParcelableArrayListExtra("extraListaDosadasnjihKvizova", listaPostojecihKvizova);
                startActivityForResult(intentDodavanjeKviza, 1);
                return true;
            }
        });
    }

    public void dodajNoviKviz(Kviz noviKviz) {
        if (noviKviz == null) return;
        listaPostojecihKvizova.add(noviKviz);
        listaPrikazanihKvizova.clear();

        /* U listu prikazanih kvizova dodaju se samo oni iz odabrane kategorije, izuzev ako je odabrana
        kategorija "Svi", ali to se svakako hendluje u listeneru za spinner */

        for (Kviz kviz : listaPostojecihKvizova) {
            if (kviz.getKategorija().getNaziv().equals(nazivIzabraneKategorije)) {
                listaPrikazanihKvizova.add(kviz);
            }
        }
    }

    public void izmijeniPostojeciKviz(Kviz noviKviz, int pozicijaUListiPostojecih) {
        listaPostojecihKvizova.get(pozicijaUListiPostojecih).setNaziv(noviKviz.getNaziv());
        listaPostojecihKvizova.get(pozicijaUListiPostojecih).setPitanja(noviKviz.getPitanja());
        listaPostojecihKvizova.get(pozicijaUListiPostojecih).setKategorija(noviKviz.getKategorija());
        listaPrikazanihKvizova.clear();
        for (Kviz kviz : listaPostojecihKvizova) {
            if (kviz.getKategorija().getNaziv().equals(nazivIzabraneKategorije)) {
                listaPrikazanihKvizova.add(kviz);
            }
        }
    }

    private void ucitajKvizoveIzFirebaseaIOsvjeziEkran() {
        UcitavanjeKvizovaReceiver ucitavanjeKvizovaReceiver = new UcitavanjeKvizovaReceiver(new Handler());
        ucitavanjeKvizovaReceiver.setReceiver(this);
        Intent intent = new Intent(this, UcitavanjeKvizovaService.class);
        intent.putExtra("extraUcitavanjeKvizovaReceiver", ucitavanjeKvizovaReceiver);
        startService(intent);
    }

    private void ucitajKategorijeIzFireBaseaIOsvjeziEkran() {
        UcitavanjeKategorijaReceiver ucitavanjeKategorijaReceiver = new UcitavanjeKategorijaReceiver(new Handler());
        ucitavanjeKategorijaReceiver.setReceiver(this);
        Intent intent = new Intent(this, UcitavanjeKategorijaService.class);
        intent.putExtra("extraUcitavanjeKategorijaReceiver", ucitavanjeKategorijaReceiver);
        startService(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {

            /* Slucaj kada je aktivnost DodajKvizAkt pozvana i vracena nazad na ovu s ciljem dodavanja
            novog kviza */

            if (resultCode == RESULT_OK) {
                /*listaPostojecihKategorija = new ArrayList<>();
                listaPostojecihKategorija = data.getParcelableArrayListExtra("extraUredjenaListaKategorija");
                dodajNoviKviz((Kviz) data.getSerializableExtra("extraPovratniKviz"));
                izbrisiFiktivnuKategoriju();
                if (ekranSiriOd550dp) onKategorijaClicked(0);
                osvjeziPodatkeNaEkranu();*/
                //prvoPrikazivanje = true;
                inicijalizirajKategorije();
            }
            else if (resultCode == RESULT_CANCELED) {

                /* Ako se korisnik vratio pritiskom na Back, potrebno je eventualno azurirati listu kategorija
                ako su dodane neke nove */

                /*listaPostojecihKategorija = new ArrayList<>();
                listaPostojecihKategorija = data.getParcelableArrayListExtra("extraUredjenaListaKategorija");
                izbrisiFiktivnuKategoriju();
                if (ekranSiriOd550dp) onKategorijaClicked(0);
                osvjeziPodatkeNaEkranu();*/
                //prvoPrikazivanje = true;
                inicijalizirajKategorije();
            }
        }
        else if (requestCode == 2) {

            /* Slucaj kada je aktivnost DodajKvizAkt pozvana i vracena nazad na ovu s ciljem izmjene
            postojeceg kviza */

            if (resultCode == RESULT_OK) {
                /*listaPostojecihKategorija = new ArrayList<>();
                listaPostojecihKategorija = data.getParcelableArrayListExtra("extraUredjenaListaKategorija");
                izmijeniPostojeciKviz((Kviz) data.getSerializableExtra("extraPovratniKviz"),
                        data.getIntExtra("extraPozicijaPovratnogKviza", 0));
                izbrisiFiktivnuKategoriju();
                if (ekranSiriOd550dp) onKategorijaClicked(0);
                osvjeziPodatkeNaEkranu();*/
                //prvoPrikazivanje = true;
                inicijalizirajKategorije();
            }
            else if (resultCode == RESULT_CANCELED) {

                /* Ako se korisnik vratio pritiskom na Back, potrebno je eventualno azurirati listu kategorija
                ako su dodane neke nove */

                /*listaPostojecihKategorija = new ArrayList<>();
                listaPostojecihKategorija = data.getParcelableArrayListExtra("extraUredjenaListaKategorija");
                izbrisiFiktivnuKategoriju();
                if (ekranSiriOd550dp) onKategorijaClicked(0);
                osvjeziPodatkeNaEkranu();*/
                //prvoPrikazivanje = true;
                inicijalizirajKategorije();
            }
        }
        else if (requestCode == 6) {

            /* Slucaj kada je aktivnost IgrajKvizAkt pozvana */

            if (resultCode == RESULT_OK) {
                inicijalizirajKategorije();
            }
            else if (resultCode == RESULT_CANCELED) {
                inicijalizirajKategorije();
            }
        }
    }

    private void osvjeziPodatkeNaEkranu() {
        izbrisiFiktivnuKategoriju();
        if (ekranSiriOd550dp) {
            osvjeziFragmentLista();
            osvjeziFragmentDetail();
        }
        else {
            osvjeziPrikazKategorija();
            osvjeziPrikazKvizova();
        }
    }

    private void osvjeziFragmentLista() {
        listaFrag = new ListaFrag();
        Bundle argumentiFragmentaLista = new Bundle();
        argumentiFragmentaLista.putParcelableArrayList("bundleListaKategorija", listaPostojecihKategorija);
        listaFrag.setArguments(argumentiFragmentaLista);
        fragmentManager.beginTransaction().replace(R.id.listPlace, listaFrag).commitAllowingStateLoss();
    }

    private void osvjeziFragmentDetail() {
        detailFrag = new DetailFrag();
        Bundle argumentiFragmentaDetail = new Bundle();
        argumentiFragmentaDetail.putParcelableArrayList("bundleListaPrikazanihKvizova", listaPrikazanihKvizova);
        detailFrag.setArguments(argumentiFragmentaDetail);
        fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commitAllowingStateLoss();
    }

    private void izbrisiFiktivnuKategoriju() {
        int pozicijaZaBrisanje = listaPostojecihKategorija.size() - 1;
        if (listaPostojecihKategorija.get(pozicijaZaBrisanje).getNaziv().equals("Dodaj kategoriju"))
            listaPostojecihKategorija.remove(pozicijaZaBrisanje);
    }

    private void osvjeziPrikazKategorija() {
        kategorijeAdapter = new KategorijeAdapter(this, listaPostojecihKategorija, getResources());
        spPostojeceKategorije.setAdapter(kategorijeAdapter);
    }

    @Override
    public void onKategorijaClicked(int position) {
        if (position >= listaPostojecihKategorija.size()) return;
        if (position == 0) {

            // Ako je kliknuto na kategoriju "Svi" prikazuju se svi kvizovi

            listaPostojecihKvizova = new ArrayList<>();
            listaPrikazanihKvizova = new ArrayList<>();
            if (!progressDialog.isShowing()) {
                progressDialog.setMessage("Ucitavanje...");
                progressDialog.show();
            }
            ucitajKvizoveIzFirebaseaIOsvjeziEkran();
        }
        else {

            // Inace, prikazuju se samo kvizovi iz odabrane kategorije

            listaPostojecihKvizova =  new ArrayList<>();
            listaPrikazanihKvizova = new ArrayList<>();
            if (!progressDialog.isShowing()) {
                progressDialog.setMessage("Ucitavanje...");
                progressDialog.show();
            }
            ucitajKvizoveIzFirebaseaPoKategorijiIOsvjeziEkran(listaPostojecihKategorija.get(position).getIdIzFirebasea());
        }
        osvjeziPodatkeNaEkranu();
        nazivIzabraneKategorije = listaPostojecihKategorija.get(position).getNaziv();
    }

    @Override
    public void onKvizLongClicked(int position) {
        Intent intentUredjivanjeKviza = new Intent(KvizoviAkt.this, DodajKvizAkt.class);

                /* Preko booleana "extraDodavanjeNovogKviza" salje se informacija aktivnosti
                DodajKvizAkt da li se treba uredjivati postojeci kviz ili dodavati novi, a u ovom
                slucaju kliknuto je na postojeci kviz, tako da se ne dodaje novi nego uredjuje postojeci */

        intentUredjivanjeKviza.putExtra("extraDodavanjeNovogKviza", false);
        if (position >= listaPrikazanihKvizova.size()) return;
        Kviz kvizZaUredjivanje = listaPrikazanihKvizova.get(position);

        // Aktivnosti DodajKvizAkt salju se postojeci podaci o kvizu za uredjivanje

        intentUredjivanjeKviza.putExtra("extraKvizZaUredjivanje", (Serializable) kvizZaUredjivanje);
        intentUredjivanjeKviza.putExtra("extraPozicijaKvizaUListi", position);
        intentUredjivanjeKviza.putParcelableArrayListExtra("extraListaKategorija",
                listaPostojecihKategorija);

                /* Aktivnosti DodajKvizAkt salje se i lista svih ostalih kvizova da bi se moglo zabraniti
                ime kviza koje vec postoji, jer je ime kviza jedinstveno */

        ArrayList<Kviz> listaOstalihKvizova = new ArrayList<>();
        for (Kviz kviz : listaPostojecihKvizova) {
            if (!kviz.getNaziv().equals(kvizZaUredjivanje.getNaziv())) {
                listaOstalihKvizova.add(kviz);
            }
        }
        intentUredjivanjeKviza.putParcelableArrayListExtra("extraListaDosadasnjihKvizova", listaOstalihKvizova);
        startActivityForResult(intentUredjivanjeKviza, 2);
    }

    @Override
    public void onKvizClickedIgrajKviz(int position) {
        Intent intentIgranjeKviza = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
        if (position >= listaPrikazanihKvizova.size()) return;
        Kviz kvizZaIgranje = listaPrikazanihKvizova.get(position);

        // Aktivnosti IgrajKvizAkt salju se postojeci podaci o kvizu za igranje

        intentIgranjeKviza.putExtra("extraKvizZaIgranje", (Serializable) kvizZaIgranje);
        startActivityForResult(intentIgranjeKviza, 6);
    }

    @Override
    public void onKvizClickedDodajKviz() {
        Intent intentDodavanjeKviza = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
        intentDodavanjeKviza.putExtra("extraDodavanjeNovogKviza",
                true);
        intentDodavanjeKviza.putParcelableArrayListExtra("extraListaKategorija",
                listaPostojecihKategorija);
        intentDodavanjeKviza.putParcelableArrayListExtra("extraListaDosadasnjihKvizova", listaPostojecihKvizova);
        startActivityForResult(intentDodavanjeKviza, 1);
    }

    @Override
    protected void onResume() {
        Log.d("statt", "onresume pozvan");
        super.onResume();
        //osvjeziPodatkeNaEkranu();
        if (ekranSiriOd550dp) onKategorijaClicked(0);
    }

    @Override
    public void naPrimanjeUcitanihKvizova(int resultCode, Bundle resultData) {
        if (resultCode == UcitavanjeKvizovaService.KVIZOVI_UCITANI) {
            if (resultData.containsKey("extraUcitaniKvizovi")) {
                ArrayList<Kviz> primljeniKvizovi = resultData.getParcelableArrayList("extraUcitaniKvizovi");
                if (primljeniKvizovi != null) {
                    Log.d("velListe", String.valueOf(primljeniKvizovi.size()));
                    listaPostojecihKvizova = new ArrayList<>();
                    listaPrikazanihKvizova = new ArrayList<>();
                    listaPostojecihKvizova.addAll(primljeniKvizovi);
                    listaPrikazanihKvizova.addAll(listaPostojecihKvizova);
                    Log.d("velListePost", String.valueOf(listaPostojecihKvizova.size()));
                    Log.d("velListePrik", String.valueOf(listaPrikazanihKvizova.size()));
                    if (ekranSiriOd550dp) osvjeziFragmentDetail();
                    else osvjeziPrikazKvizova();
                }
            }
        }
        if (progressDialog.isShowing()) progressDialog.dismiss();
    }

    @Override
    public void naPrimanjeUcitanihKategorija(int resultCode, Bundle resultData) {
        if (resultCode == UcitavanjeKategorijaService.KATEGORIJE_UCITANE) {
            if (resultData.containsKey("extraUcitaneKategorije")) {
                Log.d("status", "ima kljuc ucitane kat");
                ArrayList<Kategorija> primljeneKategorije = resultData.getParcelableArrayList("extraUcitaneKategorije");
                if (primljeneKategorije != null) {
                    listaPostojecihKategorija.addAll(primljeneKategorije);
                    if (ekranSiriOd550dp) osvjeziFragmentLista();
                    else osvjeziPrikazKategorija();
                }
            }
        }
    }

    @Override
    public void naPrimanjeUcitanihKvizovaPoKategoriji(int resultCode, Bundle resultData) {
        if (resultCode == UcitavanjeKvizovaPoKategorijiService.KVIZOVI_UCITANI_PO_KATEGORIJI) {
            if (resultData.containsKey("extraUcitaniKvizoviPoKategoriji")) {
                ArrayList<Kviz> primljeniKvizovi = resultData.getParcelableArrayList("extraUcitaniKvizoviPoKategoriji");
                if (primljeniKvizovi != null) {
                    Log.d("velListe", String.valueOf(primljeniKvizovi.size()));
                    listaPrikazanihKvizova = new ArrayList<>();
                    listaPostojecihKvizova = new ArrayList<>();
                    listaPostojecihKvizova.addAll(primljeniKvizovi);
                    listaPrikazanihKvizova.addAll(listaPostojecihKvizova);
                    Log.d("velListePost", String.valueOf(listaPostojecihKvizova.size()));
                    Log.d("velListePrik", String.valueOf(listaPrikazanihKvizova.size()));
                    if (ekranSiriOd550dp) osvjeziFragmentDetail();
                    else osvjeziPrikazKvizova();
                }
            }
        }
        if (progressDialog.isShowing()) progressDialog.dismiss();
    }
}