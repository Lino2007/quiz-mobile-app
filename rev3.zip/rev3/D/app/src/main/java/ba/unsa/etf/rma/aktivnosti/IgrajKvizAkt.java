package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.ElementRangListe;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangListaObjekat;
import ba.unsa.etf.rma.resultreceiveri.UcitavanjeRanglistePoNazivuKvizaReceiver;
import ba.unsa.etf.rma.servisi.DodavanjeElementaURanglistuService;
import ba.unsa.etf.rma.servisi.DodavanjeRanglisteService;
import ba.unsa.etf.rma.servisi.UcitavanjeRanglistePoNazivuKvizaService;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.OnItemClick, PitanjeFrag.ZahtijevanjeImenaIgraca,
        InformacijeFrag.OnButtonClick, UcitavanjeRanglistePoNazivuKvizaReceiver.Receiver {

    private int redniBrojTrenutnogPitanja;
    private int brojTacnihPitanja;
    private int brojPreostalihPitanja;
    private double procenatTacnihOdgovora;
    private ArrayList<Pitanje> listaRandomPitanja = new ArrayList<>();
    private Kviz trenutniKviz;
    private FragmentManager fragmentManager;
    private InformacijeFrag informacijeFrag;
    private PitanjeFrag pitanjeFrag;
    private RangLista rangLista;
    private RangListaObjekat rangListaKviza = new RangListaObjekat();
    private String imeIgraca = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.igraj_kviz_akt);
        pokupiPoslanePodatke();
        promijesajPitanjaURandomPoretku();
        inicijalizirajFragmentManager();
        postaviFragmentInformacije();
        postaviFragmentPitanje();
    }

    private void pokupiPoslanePodatke() {
        trenutniKviz = (Kviz) getIntent().getSerializableExtra("extraKvizZaIgranje");
        listaRandomPitanja.addAll(trenutniKviz.getPitanja());
    }

    private void promijesajPitanjaURandomPoretku() {
        Collections.shuffle(listaRandomPitanja);
    }

    private void inicijalizirajFragmentManager() {
        fragmentManager = getSupportFragmentManager();
    }

    private void postaviFragmentInformacije() {
        FrameLayout informacijePlace = (FrameLayout) findViewById(R.id.informacijePlace);
        if (informacijePlace != null) {
            informacijeFrag = (InformacijeFrag) fragmentManager.findFragmentById(R.id.informacijePlace);
            if (informacijeFrag == null) {
                informacijeFrag = new InformacijeFrag();
                Bundle argumentiFragmentaInformacije = new Bundle();
                brojTacnihPitanja = 0;
                brojPreostalihPitanja = listaRandomPitanja.size();
                procenatTacnihOdgovora = 0;
                argumentiFragmentaInformacije.putString("bundleNazivKvizaZaIgranje", trenutniKviz.getNaziv());
                argumentiFragmentaInformacije.putInt("bundleBrojTacnihPitanja", brojTacnihPitanja);
                if (brojPreostalihPitanja == 0) {
                    argumentiFragmentaInformacije.putInt("bundleBrojPreostalihPitanja", brojPreostalihPitanja);
                }
                else {
                    argumentiFragmentaInformacije.putInt("bundleBrojPreostalihPitanja", brojPreostalihPitanja - 1);
                }
                argumentiFragmentaInformacije.putDouble("bundleProcenatTacnihOdgovora", procenatTacnihOdgovora * 100);
                informacijeFrag.setArguments(argumentiFragmentaInformacije);
                fragmentManager.beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
            }
        }
    }

    private void postaviFragmentPitanje() {
        FrameLayout pitanjePlace = (FrameLayout) findViewById(R.id.pitanjePlace);
        if (pitanjePlace != null) {
            pitanjeFrag = (PitanjeFrag) fragmentManager.findFragmentById(R.id.pitanjePlace);
            if (pitanjeFrag == null) {
                pitanjeFrag = new PitanjeFrag();
                Bundle argumentiFragmentaPitanje = new Bundle();
                if (brojPreostalihPitanja != 0) {
                    argumentiFragmentaPitanje.putSerializable("bundlePitanjeZaOdgovaranje",
                            listaRandomPitanja.get(redniBrojTrenutnogPitanja));
                }
                pitanjeFrag.setArguments(argumentiFragmentaPitanje);
                fragmentManager.beginTransaction().replace(R.id.pitanjePlace, pitanjeFrag).commit();
            }
        }
    }

    @Override
    public void onBackPressed() {
        Intent intentPovratakNaKvizove = new Intent();
        setResult(RESULT_CANCELED, intentPovratakNaKvizove);
        finish();
    }

    @Override
    public void onItemClicked(int position, boolean tacanOdgovorKliknut) {
        informacijeFrag = new InformacijeFrag();
        Bundle argumentiFragmentaInformacije = new Bundle();
        argumentiFragmentaInformacije.putString("bundleNazivKvizaZaIgranje", trenutniKviz.getNaziv());
        if (tacanOdgovorKliknut) brojTacnihPitanja++;
        argumentiFragmentaInformacije.putInt("bundleBrojTacnihPitanja", brojTacnihPitanja);
        brojPreostalihPitanja--;

        // Broj preostalih pitanja je broj pitanja koja jos uvijek nisu prikazana

        if (brojPreostalihPitanja == 0) {
            argumentiFragmentaInformacije.putInt("bundleBrojPreostalihPitanja", brojPreostalihPitanja);
        }
        else {
            argumentiFragmentaInformacije.putInt("bundleBrojPreostalihPitanja", brojPreostalihPitanja - 1);
        }
        if ((listaRandomPitanja.size() != 0) && (brojPreostalihPitanja != listaRandomPitanja.size())) {
            procenatTacnihOdgovora = ((double) brojTacnihPitanja) / (listaRandomPitanja.size() - brojPreostalihPitanja);
        }
        else procenatTacnihOdgovora = 0;
        argumentiFragmentaInformacije.putDouble("bundleProcenatTacnihOdgovora", procenatTacnihOdgovora * 100);
        informacijeFrag.setArguments(argumentiFragmentaInformacije);
        getSupportFragmentManager().beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
        pitanjeFrag = new PitanjeFrag();
        Bundle argumentiFragmentaPitanje = new Bundle();
        if (brojPreostalihPitanja != 0) {
            argumentiFragmentaPitanje.putSerializable("bundlePitanjeZaOdgovaranje",
                    listaRandomPitanja.get(++redniBrojTrenutnogPitanja));
        }
        pitanjeFrag.setArguments(argumentiFragmentaPitanje);
        fragmentManager.beginTransaction().replace(R.id.pitanjePlace, pitanjeFrag).commit();
    }

    @Override
    public void onButtonClicked() {
        Intent intentPovratakNaKvizove = new Intent();
        setResult(RESULT_OK, intentPovratakNaKvizove);
        finish();
    }

    @Override
    public void pitajIgracaZaIme() {
        prikaziAlertZahtijevanjeImenaIgraca();
    }

    private void prikaziAlertZahtijevanjeImenaIgraca() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Unesite svoje ime:");
        final EditText editText = new EditText(this);
        alertDialogBuilder.setView(editText);
        alertDialogBuilder.setNeutralButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

            }
        });
        final AlertDialog dijalogZaIme = alertDialogBuilder.create();
        dijalogZaIme.show();
        dijalogZaIme.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imeIgraca = editText.getText().toString();
                if (imeIgraca.trim().length() != 0) {
                    dijalogZaIme.dismiss();
                    ucitajRangListuIzFirebasea();
                }
            }
        });
    }

    private void ucitajRangListuIzFirebasea() {
        UcitavanjeRanglistePoNazivuKvizaReceiver ucitavanjeRanglistePoNazivuKvizaReceiver = new UcitavanjeRanglistePoNazivuKvizaReceiver(new Handler());
        ucitavanjeRanglistePoNazivuKvizaReceiver.setReceiver(this);
        Intent intent = new Intent(this, UcitavanjeRanglistePoNazivuKvizaService.class);
        intent.putExtra("extraUcitavanjeRangListePoNazivuKvizaReceiver", ucitavanjeRanglistePoNazivuKvizaReceiver);
        intent.putExtra("extraNazivZadanogKviza", trenutniKviz.getNaziv());
        startService(intent);
    }

    private void postaviFragmentRangLista() {
        FrameLayout pitanjePlace = (FrameLayout) findViewById(R.id.pitanjePlace);
        if (pitanjePlace != null) {
            rangLista = new RangLista();
            Bundle argumentiFragmentaRangLista = new Bundle();
            ArrayList<String> rangListaIgraca = new ArrayList<>();
            for (int i = 0; i < rangListaKviza.getLista().size(); i++) {
                rangListaIgraca.add(String.valueOf(i + 1) + ". " + rangListaKviza.getLista().get(i).toString());
            }
            argumentiFragmentaRangLista.putStringArrayList("bundleRangListaIgraca", rangListaIgraca);
            rangLista.setArguments(argumentiFragmentaRangLista);
            fragmentManager.beginTransaction().replace(R.id.pitanjePlace, rangLista).commit();
        }
    }

    @Override
    public void naPrimanjeUcitaneRangListePoNazivuKviza(int resultCode, Bundle resultData) {
        if (resultCode == UcitavanjeRanglistePoNazivuKvizaService.NEMA_RANGLISTE_U_BAZI) {
            rangListaKviza.setNazivKviza(trenutniKviz.getNaziv());
            double tempProcenat = procenatTacnihOdgovora * 100;
            double zaokruzeniProcenatTacnihOdgovora = Math.round(tempProcenat * 100.0) / 100.0;
            String procenatPretvorenUString = String.valueOf(zaokruzeniProcenatTacnihOdgovora);
            rangListaKviza.dodajNoviElementUListu(new ElementRangListe(imeIgraca, procenatPretvorenUString));
            rangListaKviza.sortirajListu();
            dodajNovuRangListuListuUFirebase();
            postaviFragmentRangLista();
        }
        else if (resultCode == UcitavanjeRanglistePoNazivuKvizaService.RANGLISTA_UCITANA_PO_NAZIVU_KVIZA) {
            RangListaObjekat primljenaLista = (RangListaObjekat) resultData.getSerializable("extraUcitanaRangListaPoKvizu");
            if (primljenaLista != null) rangListaKviza = primljenaLista;
            double tempProcenat = procenatTacnihOdgovora * 100;
            double zaokruzeniProcenatTacnihOdgovora = Math.round(tempProcenat * 100.0) / 100.0;
            String procenatPretvorenUString = String.valueOf(zaokruzeniProcenatTacnihOdgovora);
            rangListaKviza.dodajNoviElementUListu(new ElementRangListe(imeIgraca, procenatPretvorenUString));
            rangListaKviza.sortirajListu();
            izmijeniPostojecuRangListuUFirebaseu();
            postaviFragmentRangLista();
        }
    }

    private void dodajNovuRangListuListuUFirebase() {
        Intent intent = new Intent(this, DodavanjeRanglisteService.class);
        intent.putExtra("extraRangListaZaDodavanje", (Serializable) rangListaKviza);
        startService(intent);
    }

    private void izmijeniPostojecuRangListuUFirebaseu() {
        Intent intent = new Intent(this, DodavanjeElementaURanglistuService.class);
        intent.putExtra("extraRangListaZaMijenjanje", (Serializable) rangListaKviza);
        startService(intent);
    }
}
