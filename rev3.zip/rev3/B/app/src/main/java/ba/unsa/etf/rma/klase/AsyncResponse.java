package ba.unsa.etf.rma.klase;

public interface AsyncResponse {
    void zavrsenProces(String izlaz);

}
