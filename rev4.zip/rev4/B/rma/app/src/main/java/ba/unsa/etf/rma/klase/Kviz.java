package ba.unsa.etf.rma.klase;

import java.util.ArrayList;

public class Kviz {
    String naziv;
    ArrayList<Pitanje> pitanja;
    Kategorija kategorija;

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public String getNaziv() {
        return naziv;
    }

    void dodajPitanje(Pitanje p) {
        pitanja.add(p);
    }
}
