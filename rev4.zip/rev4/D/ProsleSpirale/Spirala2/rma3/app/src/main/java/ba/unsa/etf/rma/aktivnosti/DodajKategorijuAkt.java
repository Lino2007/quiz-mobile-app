package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;
import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;

public class DodajKategorijuAkt extends AppCompatActivity  implements IconDialog.Callback  {
    EditText etNaziv;
    EditText etIkona;
    Button btnDodajIkonu;
    Button btnDodajKategoriju;

    Icon[] selectedIcons;
    IconDialog iconDialog;

    ArrayList<String> kategorijeNazivi;
    ArrayList<Kategorija> kategorije;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);

        etNaziv = findViewById(R.id.etNaziv);
        etIkona = findViewById(R.id.etIkona);
        btnDodajIkonu = findViewById(R.id.btnDodajIkonu);
        btnDodajKategoriju = findViewById(R.id.btnDodajKategoriju);

        etIkona.setFocusable(false);


        iconDialog = new IconDialog();

        kategorije = (ArrayList<Kategorija>) getIntent().getBundleExtra("Bundle").getSerializable("Kategorije");
        kategorijeNazivi = new ArrayList<>();
        kategorijePrevediUStringove();


        btnDodajIkonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });

        btnDodajKategoriju.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean prviUslov = jedinstvenNazivKategorije(etNaziv.getText().toString().trim());
                Boolean drugiUslov  = postojiIkona();
                if(prviUslov && drugiUslov){
                    Kategorija novaNova = new Kategorija(etNaziv.getText().toString(), etIkona.getText().toString());
                    kategorije.add(novaNova);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("Kategorije",kategorije);
                    Intent intent = new Intent();
                    intent.putExtra("Bundle",bundle);
                    setResult(402, intent);
                    finish();
                }
            }
        });


    }
    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        etIkona.setText(selectedIcons[0].getId() + "");
    }
    public void kategorijePrevediUStringove(){
        for(int i=0;i<kategorije.size();i++){
            kategorijeNazivi.add(kategorije.get(i).getNaziv());
            Log.e("Tag", kategorijeNazivi.get(i));
        }
    }
    public Boolean jedinstvenNazivKategorije(String s){
        for(int i = 0; i<kategorijeNazivi.size(); i++){
            if(kategorijeNazivi.get(i).equals(s)){
                etNaziv.setBackgroundColor(getResources().getColor(R.color.boja1));
                return false;
            }
        }
        if(etNaziv.getText().toString().equals("") || etNaziv.getText() == null){
            etNaziv.setBackgroundColor(getResources().getColor(R.color.boja1));
            return false;
        }
        etNaziv.setBackgroundColor(Color.WHITE);
        return true;
    }
    public Boolean postojiIkona(){
        if(etIkona.getText().toString().equals("") || etIkona.getText() == null) {
            etIkona.setBackgroundColor(getResources().getColor(R.color.boja1));
            return false;
        }
        etIkona.setBackgroundColor(Color.WHITE);
        return true;
    }

}
