package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.asyncKlase.DobaviIdKvizaIzBaze;
import ba.unsa.etf.rma.asyncKlase.DohvatiSvaPitanja;
import ba.unsa.etf.rma.asyncKlase.DohvatiSveKategorije;
import ba.unsa.etf.rma.asyncKlase.PatchKviz;
import ba.unsa.etf.rma.asyncKlase.PostajKviz;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajKvizAkt extends AppCompatActivity implements DohvatiSveKategorije.IDohvatiKategorije,DohvatiSvaPitanja.IDohvatiSvaPitanja, PostajKviz.IPostajKviz,
        DobaviIdKvizaIzBaze.IDobaviIdKvizaIzBaze, PatchKviz.IPatchKviz {
    public static Context context;
    Kviz KvizZaSpiraluTriToBreakIt;
    String popratniLinkZaPATCHKviza = "";
    Spinner spKategorije;
    EditText etNaziv;
    ListView lvDodanaPitanja;
    ListView lvMogucaPitanja;
    Button btnDodajKviz;

    Kviz kviz;
    ArrayList<String> sveKategorije;
    ArrayList<Kategorija> kategorije;

    ArrayList<Pitanje> pitanja;
    ArrayList<String> svaPitanja;

    ArrayList<String> pitanjaKviza;
    Boolean novi = true;

    ArrayList<Kviz> kvizovi;

    //Spirala 2
    Button btnImportKviz;


    Kviz importKvizSpirala2 = new Kviz("Prazni");
    Boolean pravilnoDodan = false;
    //Spirala 2 end
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);
        context=this;

        spKategorije = findViewById(R.id.spKategorije);
        etNaziv = findViewById(R.id.etNaziv);
        lvDodanaPitanja = findViewById(R.id.lvDodanaPitanja);
        lvMogucaPitanja = findViewById(R.id.lvMogucaPitanja);
        btnDodajKviz = findViewById(R.id.btnDodajKviz);

        //Spirala 2
        btnImportKviz = findViewById(R.id.btnImportKviz);
        //Spirala 2 end




        kviz = (Kviz) getIntent().getBundleExtra("Bundle").getSerializable("Kviz");
        kvizovi = (ArrayList<Kviz>) getIntent().getBundleExtra("Bundle").getSerializable("Kvizovi");
        //kategorije = (ArrayList<Kategorija>) getIntent().getBundleExtra("Bundle").getSerializable("Kategorije");
        kategorije = new ArrayList<>();
        new DohvatiSveKategorije((DohvatiSveKategorije.IDohvatiKategorije)DodajKvizAkt.this).execute("proba2");
        sveKategorije = new ArrayList<>();


        new DohvatiSvaPitanja(DodajKvizAkt.this).execute("proba2");
        //pitanja = (ArrayList<Pitanje>) getIntent().getBundleExtra("Bundle").getSerializable("Pitanja");
        svaPitanja = new ArrayList<>();
        //for(int i = 0; i<pitanja.size();i++){
        //    svaPitanja.add(pitanja.get(i).getNaziv());
        //}
        pitanjaKviza = new ArrayList<>();
        //for(int i = 0; i<kviz.getPitanja().size(); i++){
        //    pitanjaKviza.add(kviz.getPitanja().get(i).getNaziv());
        //}
        //pitanjaKviza.add("Dodaj Pitanje");

        if(!kviz.getNaziv().equals("Dodaj Kviz")){
            etNaziv.setFocusable(false);
            etNaziv.setText(kviz.getNaziv());
            novi = false;
        }
        postaviSpinnerAdapter();
        postaviAdaptere();

        lvDodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i == pitanjaKviza.size()-1){
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("Kvizovi", kvizovi);
                    bundle.putSerializable("Pitanja",pitanja);
                    bundle.putSerializable("Kategorije",kategorije);
                    bundle.putSerializable("Kviz", kviz);
                    Intent intent = new Intent(DodajKvizAkt.this,DodajPitanjeAkt.class);
                    intent.putExtra("Bundle",bundle);
                    startActivityForResult(intent,203);
                }
                else{
                    String temp = pitanjaKviza.get(i);
                    pitanjaKviza.remove(i);
                    svaPitanja.add(temp);
                    postaviAdaptere();
                }
            }
        });
        lvMogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String temp = svaPitanja.get(i);
                svaPitanja.remove(i);
                pitanjaKviza.add(0,temp);
                postaviAdaptere();
            }
        });

        btnDodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(novi){
                    Boolean mozeMoze = true;
                    String x = etNaziv.getText().toString();


                    if(x.trim().equals("") || x == null){
                        etNaziv.setBackgroundColor(getResources().getColor(R.color.boja1));
                        mozeMoze = false;
                    }
                    else{
                        etNaziv.setBackgroundColor(Color.WHITE);
                    }


                    if(pitanjaKviza.size() == 1){
                        lvDodanaPitanja.setBackgroundColor(getResources().getColor(R.color.boja1));
                        mozeMoze = false;
                    }
                    else{
                        lvDodanaPitanja.setBackgroundColor(Color.WHITE);
                    }

                    for(int i = 0; i<kvizovi.size(); i++){
                        if(kvizovi.get(i).getNaziv().equals(x.trim())){
                            mozeMoze = false;
                            etNaziv.setBackgroundColor(getResources().getColor(R.color.boja1));
                            break;
                        }
                    }
                    String y = spKategorije.getSelectedItem().toString();
                    if(y.equals("X Molimo izaberite kategoriju X")){
                        mozeMoze = false;
                        spKategorije.setBackgroundColor(getResources().getColor(R.color.boja1));
                    }
                    else{
                        spKategorije.setBackgroundColor(Color.LTGRAY);
                    }
                    if(mozeMoze){
                        Kategorija trazimikategoriju = dajKategoriju(y);
                        ArrayList<Pitanje> trazimilistupitanja = dajPitanjaList();
                        if(!trazimikategoriju.getNaziv().equals("Greska")){
                            /*
                            Kviz noviNovi = new Kviz(x,trazimilistupitanja,trazimikategoriju);
                            kvizovi.add(noviNovi);
                            kviz = noviNovi;
                            Intent intent = dajIntent();
                            setResult(201, intent);
                            finish();
                            */
                            String[] ex = new String[2+trazimilistupitanja.size()];
                            ex[0] = etNaziv.getText().toString();
                            ex[1] = trazimikategoriju.getNaziv();
                            for(int i=0; i<trazimilistupitanja.size(); i++){
                                ex[2+i] = trazimilistupitanja.get(i).getNaziv();
                            }
                            new PostajKviz(DodajKvizAkt.this).execute(ex);
                        }
                    }
                }
                else{
                    if(pitanjaKviza.size() == 1){
                        lvDodanaPitanja.setBackgroundColor(getResources().getColor(R.color.boja1));
                    }
                    else{
                        lvDodanaPitanja.setBackgroundColor(Color.WHITE);
                        String y = spKategorije.getSelectedItem().toString();
                        if(y.equals("X Molimo izaberite kategoriju X")){
                            spKategorije.setBackgroundColor(getResources().getColor(R.color.boja1));
                        }
                        else{
                            spKategorije.setBackgroundColor(Color.LTGRAY);
                            Kategorija trazimikategoriju = dajKategoriju(y);
                            ArrayList<Pitanje> trazimilistupitanja = dajPitanjaList();

                            int indexItema = -1;
                            for(int i=0;i<kvizovi.size();i++){
                                if(kvizovi.get(i).getNaziv().equals(kviz.getNaziv())) indexItema = i;
                            }

                            if(indexItema != -1 && !trazimikategoriju.equals("Greska")){
                                /*
                                kvizovi.get(indexItema).setKategorija(trazimikategoriju);
                                kvizovi.get(indexItema).setPitanja(trazimilistupitanja);
                                Intent intent = dajIntent();
                                setResult(201, intent);
                                finish();
                                */
                                KvizZaSpiraluTriToBreakIt = kvizovi.get(indexItema);
                                KvizZaSpiraluTriToBreakIt.setKategorija(trazimikategoriju);
                                KvizZaSpiraluTriToBreakIt.setPitanja(trazimilistupitanja);
                                new DobaviIdKvizaIzBaze(DodajKvizAkt.this).execute(kviz.getNaziv());
                            }
                        }
                    }
                }
            }
        });

        spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i == sveKategorije.size()-1){
                    spKategorije.setSelection(0);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("Kvizovi", kvizovi);
                    bundle.putSerializable("Pitanja",pitanja);
                    bundle.putSerializable("Kategorije",kategorije);
                    bundle.putSerializable("Kviz",kviz);
                    Intent intent = new Intent(DodajKvizAkt.this,DodajKategorijuAkt.class);
                    intent.putExtra("Bundle",bundle);
                    startActivityForResult(intent,204);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        //Spirala 2
        btnImportKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("text/plain");
                startActivityForResult(intent, 205);
            }
        });

        //Spirala 2 end




    }
    public void postaviSpinnerAdapter(){
        sveKategorije = new ArrayList<>();
        sveKategorije.add("X Molimo izaberite kategoriju X");
        int postaviNaOvaj = -1;
        for(int i=1; i<kategorije.size(); i++){
            sveKategorije.add(kategorije.get(i).getNaziv());
            if(kviz.getKategorija().getNaziv().equals(kategorije.get(i).getNaziv())) postaviNaOvaj = i;
        }
        sveKategorije.add("Dodaj Kategoriju");
        spKategorije.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,sveKategorije));
        if(!novi && postaviNaOvaj != -1)spKategorije.setSelection(postaviNaOvaj);
    }
    public void postaviAdaptere(){
        /*
        sveKategorije = new ArrayList<>();
        int postaviNaOvaj = -1;
        for(int i=1; i<kategorije.size(); i++){
            sveKategorije.add(kategorije.get(i).getNaziv());
            if(kviz.getKategorija().getNaziv().equals(kategorije.get(i).getNaziv())) postaviNaOvaj = i - 1;
        }
        sveKategorije.add("Dodaj Kategoriju");
        spKategorije.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,sveKategorije));
        if(!novi && postaviNaOvaj != -1)spKategorije.setSelection(postaviNaOvaj);
        */

        for(int i=0;i<svaPitanja.size(); i++){
            for(int j=0; j<pitanjaKviza.size();j++){
                if(svaPitanja.get(i).equals(pitanjaKviza.get(j))){
                    svaPitanja.set(i,"123456789X");
                }
            }
        }
        for(int i=0;i<svaPitanja.size();i++){
            if(svaPitanja.get(i).equals("123456789X")){
                svaPitanja.remove(i);
                i--;
            }
        }
        lvDodanaPitanja.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,pitanjaKviza));
        lvMogucaPitanja.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,svaPitanja));

    }

    public Kategorija dajKategoriju(String y){
        Kategorija trazimikategoriju = new Kategorija("Greska","Greska");
        for(int i=0;i<kategorije.size();i++){
            if(kategorije.get(i).getNaziv().equals(y)){
                trazimikategoriju = kategorije.get(i);
            }
        }
        return trazimikategoriju;
    }

    public ArrayList<Pitanje> dajPitanjaList(){
        ArrayList<Pitanje> trazimilistupitanja = new ArrayList<>();
        for(int i=0;i<pitanjaKviza.size()-1;i++){
            for(int j=0; j<pitanja.size(); j++){
                if(pitanja.get(j).getNaziv().equals(pitanjaKviza.get(i))){
                    trazimilistupitanja.add(pitanja.get(j));
                }
            }
        }
        return trazimilistupitanja;
    }
    public Intent dajIntent(){
        Bundle bundle = new Bundle();
        bundle.putSerializable("Kvizovi", kvizovi);
        bundle.putSerializable("Pitanja",pitanja);
        bundle.putSerializable("Kategorije",kategorije);
        bundle.putSerializable("Kviz",kviz);
        Intent intent = new Intent();
        intent.putExtra("Bundle",bundle);
        return intent;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 203){
            if(resultCode == 302){
                new DohvatiSvaPitanja(DodajKvizAkt.this).execute("proba2");
                /*
                kvizovi = (ArrayList<Kviz>) data.getBundleExtra("Bundle").getSerializable("Kvizovi");
                kviz = (Kviz) data.getBundleExtra("Bundle").getSerializable("Kviz");
                pitanja = (ArrayList<Pitanje>) data.getBundleExtra("Bundle").getSerializable("Pitanja");
                svaPitanja.add(pitanja.get(pitanja.size()-1).getNaziv());
                pitanjaKviza.remove(pitanjaKviza.size()-1);
                pitanjaKviza.add(pitanja.get(pitanja.size()-1).getNaziv());
                pitanjaKviza.add("Dodaj Pitanje");
                postaviAdaptere();
                 */
            }
        }
        if(requestCode == 204){
            if(resultCode == 402){
                //kategorije = (ArrayList<Kategorija>) data.getBundleExtra("Bundle").getSerializable("Kategorije");
                //postaviSpinnerAdapter();
                new DohvatiSveKategorije((DohvatiSveKategorije.IDohvatiKategorije)DodajKvizAkt.this).execute("proba2");
            }
        }
        if(requestCode == 205 && resultCode == Activity.RESULT_OK){
            Uri uri = null;
            if (data != null) {
                uri = data.getData();
                try {
                    ArrayList<String> importovani_kviz = readTextFromUri(uri);
                    importujKvizIzFile(importovani_kviz);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public ArrayList<String> readTextFromUri(Uri uri) throws IOException {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        ArrayList<String> fileString = new ArrayList<>();
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line);
            fileString.add(line.toString());
        }
        reader.close();
        inputStream.close();
        return fileString;
    }
    public void importujKvizIzFile(ArrayList<String> informacijeKviza){
        if(informacijeKviza.size() == 0) return;
        String[] items = informacijeKviza.get(0).split(",");
        int brojac = 1;
        for(int i=0; i<informacijeKviza.get(0).length(); i++){
            if(informacijeKviza.get(0).charAt(i) == ',') brojac++;
        }
        if(brojac == 3){
            Boolean dalje = true;
            dalje = postaviNazivKvizaUET(items[0]);
            if(dalje){
                importujKategoriju(items[1]);
                int brojPitanja = Integer.parseInt(items[2]);
                dalje = provjeriBrojRedovaFile(informacijeKviza, brojPitanja);
                if(dalje){
                    dodajPitanja(informacijeKviza);
                    importujKvizNaActivity();
                }
                else{
                    new AlertDialog.Builder(this)
                            .setTitle("Poruka za broj pitanja")
                            .setMessage("Kviz kojeg imporujete ima neispravan broj pitanja!")
                            .setNegativeButton(android.R.string.no, null)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                    return;
                }
            }
            else{
                new AlertDialog.Builder(this)
                        .setTitle("Poruka za ime kviza")
                        .setMessage("Kviz kojeg importujete vec postoji!")
                        .setNegativeButton(android.R.string.no, null)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
                return;
            }
        }


    }
    public Boolean postaviNazivKvizaUET(String nazivKviza){
        for(int i=0; i<kvizovi.size(); i++){
            if(kvizovi.get(i).getNaziv().equals(nazivKviza.trim())){
                return false;
            }
        }
        importKvizSpirala2.setNaziv(nazivKviza);
        return true;
    }
    public void importujKategoriju(String importovanaKategorija){
        Kategorija novaKategorija = null;

        for(int i=0; i<kategorije.size();i++){
            if(kategorije.get(i).equals(importovanaKategorija.trim())){
                novaKategorija = kategorije.get(i);
                importKvizSpirala2.setKategorija(novaKategorija);
                //spKategorije.setSelection(i);
            }
        }
        if(novaKategorija == null){
            novaKategorija = new Kategorija(importovanaKategorija.trim(), "22");
            importKvizSpirala2.setKategorija(novaKategorija);
            /*
            kategorije.add(novaKategorija);
            postaviSpinnerAdapter();
            spKategorije.setSelection(kategorije.size()-1);
             */
        }
    }
    public Boolean provjeriBrojRedovaFile(ArrayList<String> file, int brojRedova){
        if(file.size()-1 != brojRedova || brojRedova==0) return false;
        return true;
    }
    public void dodajPitanja(ArrayList<String> informacijeKviza){
        ArrayList<Pitanje> importovanaPitanja = new ArrayList<>();
        for(int i=1; i<informacijeKviza.size();i++){
            Pitanje novoPitanje;
            String[] informacije = informacijeKviza.get(i).split(",");

            int brojac = 1;
            for(int b=0; b<informacijeKviza.get(i).length(); b++) {
                if(informacijeKviza.get(i).charAt(b) == ',') brojac++;
            }

            if(brojac >3){
                novoPitanje = new Pitanje(informacije[0],informacije[0],new ArrayList<String>(),"");
                int broj_odgovora = Integer.parseInt(informacije[1]);
                int tacan_odgovor = Integer.parseInt(informacije[2]);
                if(broj_odgovora == brojac - 3){
                    if(tacan_odgovor>=0 && tacan_odgovor<broj_odgovora){
                        for(int j=3; j<brojac ; j++){
                            novoPitanje.getOdgovori().add(informacije[j]);
                            if(j==tacan_odgovor+3) {
                                novoPitanje.setTacan(informacije[j]);
                            }
                        }
                    }
                    else{
                        new AlertDialog.Builder(this)
                                .setTitle("Poruka za tacan odgovor pitanja")
                                .setMessage("Kviz kojeg importujete ima neispravan index tacnog odgovora!")
                                .setNegativeButton(android.R.string.no, null)
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();
                        return;
                    }
                }
                else{
                    new AlertDialog.Builder(this)
                            .setTitle("Poruka za odgovore pitanja")
                            .setMessage("Kviz kojeg importujete ima neispravan broj odgovora!")
                            .setNegativeButton(android.R.string.no, null)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                    return;
                }
            }
            else{
                new AlertDialog.Builder(this)
                        .setTitle("Poruka za odgovore pitanja")
                        .setMessage("Kviz kojeg importujete ima neispravan broj odgovora!")
                        .setNegativeButton(android.R.string.no, null)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
                return;
            }
            importovanaPitanja.add(novoPitanje);
        }
        pravilnoDodan = true;
        importKvizSpirala2.setPitanja(importovanaPitanja);
    }
    public void importujKvizNaActivity(){
        if(pravilnoDodan){
            etNaziv.setText(importKvizSpirala2.getNaziv());

            Boolean postojiKategorijaSpirala2 = false;
            for(int i=0; i<kategorije.size();i++){
                if(kategorije.get(i).getNaziv().equals(importKvizSpirala2.getKategorija().getNaziv())){
                    spKategorije.setSelection(i);
                    postojiKategorijaSpirala2 = true;
                }
            }
            if(!postojiKategorijaSpirala2){
                kategorije.add(importKvizSpirala2.getKategorija());
                postaviSpinnerAdapter();
                spKategorije.setSelection(kategorije.size()-1);
            }


            Boolean postojiPitanjeSpirala2 = false;
            for(int i=0; i<importKvizSpirala2.getPitanja().size(); i++){
                postojiPitanjeSpirala2 = false;
                for(int j=0; j<pitanja.size(); j++){
                    if(pitanja.get(j).getNaziv().trim().equals(importKvizSpirala2.getPitanja().get(i).getNaziv().trim())){
                        postojiPitanjeSpirala2 = true;
                        pitanja.get(j).setNaziv(importKvizSpirala2.getPitanja().get(i).getNaziv());
                        pitanja.get(j).setTekstPitanja(importKvizSpirala2.getPitanja().get(i).getTekstPitanja());
                        pitanja.get(j).setTacan(importKvizSpirala2.getPitanja().get(i).getTacan());
                        pitanja.get(j).setOdgovori(importKvizSpirala2.getPitanja().get(i).getOdgovori());
                    }
                }
                if(!postojiPitanjeSpirala2){
                    pitanja.add(importKvizSpirala2.getPitanja().get(i));
                    svaPitanja.add(importKvizSpirala2.getPitanja().get(i).getNaziv());
                }
            }
            postaviAdaptere();

        }
        pravilnoDodan = false;
    }

    @Override
    public void onDohvatiKategorijeDone(ArrayList<Kategorija> rezultat) {
        kategorije = new ArrayList<>();
        kategorije.add(new Kategorija("Svi", "0"));
        for(int i=0; i<rezultat.size(); i++){
            kategorije.add(rezultat.get(i));
        }
        postaviSpinnerAdapter();
        postaviAdaptere();
    }

    @Override
    public void onDohvatiSvaPitanja(ArrayList<Pitanje> rezultat) {
        pitanja = rezultat;
        svaPitanja = new ArrayList<>();
        for(int i = 0; i<pitanja.size();i++){
            svaPitanja.add(pitanja.get(i).getNaziv());
        }
        pitanjaKviza = new ArrayList<>();
        for(int i = 0; i<kviz.getPitanja().size(); i++){
            pitanjaKviza.add(kviz.getPitanja().get(i).getNaziv());
        }
        pitanjaKviza.add("Dodaj Pitanje");
        postaviAdaptere();

    }

    @Override
    public void onPostajKviz() {
        Kviz noviNovi = new Kviz("x",new ArrayList<Pitanje>(),kategorije.get(1));
        kvizovi.add(noviNovi);
        kviz = noviNovi;
        Intent intent = dajIntent();
        setResult(201, intent);
        finish();
    }

    @Override
    public void onDobaviIdKvizaIzBaze(String linkID) {
        popratniLinkZaPATCHKviza = linkID;
        String[] ex = new String[3+KvizZaSpiraluTriToBreakIt.getPitanja().size()];
        ex[0] = popratniLinkZaPATCHKviza;
        ex[1] = etNaziv.getText().toString();
        ex[2] = KvizZaSpiraluTriToBreakIt.getKategorija().getNaziv();
        for(int i=0; i<KvizZaSpiraluTriToBreakIt.getPitanja().size(); i++){
            ex[3+i] = KvizZaSpiraluTriToBreakIt.getPitanja().get(i).getNaziv();
        }
        new PatchKviz(DodajKvizAkt.this).execute(ex);
    }

    @Override
    public void onPatchKviz() {
        Intent intent = dajIntent();
        setResult(201, intent);
        finish();
    }
}
