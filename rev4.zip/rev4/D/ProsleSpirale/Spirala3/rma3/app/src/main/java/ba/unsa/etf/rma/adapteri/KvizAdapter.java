package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconHelper;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

import java.util.ArrayList;
import java.util.List;


public class KvizAdapter extends ArrayAdapter<Kviz> {

    int resource;
    Context context;
    ArrayList<Kviz> list;
    IconHelper iconHelper;

    public KvizAdapter(@NonNull Context context, int resource, ArrayList<Kviz> fullList) {
        super(context, resource, fullList);
        this.resource = resource;
        this.context = context;
        this.list = fullList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        LinearLayout view;
        if(convertView == null){
            view = new LinearLayout(getContext());
            String inflater = Context.LAYOUT_INFLATER_SERVICE;
            LayoutInflater layoutInflater;
            layoutInflater = (LayoutInflater) getContext().getSystemService(inflater);
            layoutInflater.inflate(resource,view,true);
        }
        else{
            view = (LinearLayout) convertView;
        }

        final ImageView imgKategorija = view.findViewById(R.id.imgKategorija);
        TextView txtKviz = view.findViewById(R.id.txtKviz);

        Kviz trenutni = list.get(position);
        txtKviz.setText(trenutni.getNaziv());
        if(trenutni.getKategorija().getId().equals("DodajKviz666")){
            imgKategorija.setImageResource(R.drawable.slika);
        }
        else{
            final int idSlike = Integer.parseInt(trenutni.getKategorija().getId());
            iconHelper = IconHelper.getInstance(context);
            iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
                @Override
                public void onDataLoaded() {
                    imgKategorija.setImageDrawable(iconHelper.getIcon(idSlike).getDrawable(context));

                }
            });


        }
        return view;
    }
}
