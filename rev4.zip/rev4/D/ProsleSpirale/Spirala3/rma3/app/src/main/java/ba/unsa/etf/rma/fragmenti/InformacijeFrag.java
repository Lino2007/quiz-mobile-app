package ba.unsa.etf.rma.fragmenti;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

/**
 * A simple {@link Fragment} subclass.
 */
public class InformacijeFrag extends Fragment {
    TextView infNazivKviza;
    TextView infBrojTacnihPitanja;
    TextView infBrojPreostalihPitanja;
    TextView infProcenatTacni;
    Button btnKraj;

    Kviz kviz;
    ArrayList<Integer> info;

    //Interface
    klikBtnKraj btnKlik;

    public InformacijeFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_informacije, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        infNazivKviza = getView().findViewById(R.id.infNazivKviza);
        infBrojTacnihPitanja = getView().findViewById(R.id.infBrojTacnihPitanja);
        infBrojPreostalihPitanja = getView().findViewById(R.id.infBrojPreostalihPitanja);
        infProcenatTacni = getView().findViewById(R.id.infProcenatTacni);
        btnKraj = getView().findViewById(R.id.btnKraj);

        kviz = (Kviz) getArguments().getSerializable("Kviz");
        info = (ArrayList<Integer>) getArguments().getIntegerArrayList("Informacije");


        updateInformacije();

        btnKraj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnKlik = (klikBtnKraj)getActivity();
                btnKlik.klik();
            }
        });

    }

    public void updateInformacije(){
        infNazivKviza.setText(kviz.getNaziv());
        infBrojTacnihPitanja.setText("" + info.get(0));
        if(info.get(2) == -1){
            infBrojPreostalihPitanja.setText("0");
        }
        else{
            infBrojPreostalihPitanja.setText("" + info.get(2));
        }
        if(info.get(1) == 0){
            infProcenatTacni.setText("/");
        }
        else{
            String ispis = "" + (info.get(0)*100.0/info.get(1));
            infProcenatTacni.setText(ispis + "%");
        }
    }

    public interface klikBtnKraj{
        public void klik();
    }

}
