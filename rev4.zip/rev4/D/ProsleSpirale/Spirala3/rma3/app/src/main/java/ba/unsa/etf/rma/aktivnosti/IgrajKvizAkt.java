package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.klase.Kviz;

public class IgrajKvizAkt extends AppCompatActivity implements InformacijeFrag.klikBtnKraj, PitanjeFrag.odgovorioPitanje{
    Kviz kviz;
    FragmentManager fragmentManager;
    InformacijeFrag informacijeFrag;
    PitanjeFrag pitanjeFrag;

    ArrayList<Integer> info;
    int brojTacnih = 0;
    int brojOdgovorenih = 0;
    int brojPreostalih;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);


        kviz = (Kviz) getIntent().getBundleExtra("Bundle").getSerializable("Kviz");
        info = new ArrayList<>();
        info.add(0);
        info.add(0);
        info.add(kviz.getPitanja().size()-1);



        fragmentManager = getSupportFragmentManager();
        FrameLayout informacijePlace = (FrameLayout)findViewById(R.id.informacijePlace);
        FrameLayout pitanjePlace = (FrameLayout)findViewById(R.id.pitanjePlace);



        Bundle argumenti = new Bundle();
        argumenti.putSerializable("Kviz",kviz);
        argumenti.putIntegerArrayList("Informacije",info);

        if(informacijePlace != null && pitanjePlace  != null){
            informacijeFrag = new InformacijeFrag();
            pitanjeFrag = new PitanjeFrag();
            informacijeFrag.setArguments(argumenti);
            pitanjeFrag.setArguments(argumenti);
            fragmentManager.beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
            fragmentManager.beginTransaction().replace(R.id.pitanjePlace, pitanjeFrag).commit();
        }

    }

    @Override
    public void klik() {
        Intent intent = new Intent();
        setResult(601, intent);
        finish();
    }

    @Override
    public void odgovorio(Boolean x) {
        info.set(1,info.get(1)+1);
        if(x){
            info.set(0,info.get(0)+1);
        }
        info.set(2,info.get(2)-1);

        Bundle argumenti = new Bundle();
        argumenti.putSerializable("Kviz",kviz);
        argumenti.putIntegerArrayList("Informacije",info);
        FrameLayout informacijePlace = (FrameLayout)findViewById(R.id.informacijePlace);
        if(informacijePlace != null){
            informacijeFrag = new InformacijeFrag();
            informacijeFrag.setArguments(argumenti);
            fragmentManager.beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
        }

    }
}
