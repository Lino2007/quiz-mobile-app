package ba.unsa.etf.rma.baza;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class BazaOpenHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "LibraryDB.db";
    public static final int DATABASE_VERSION = 9;

    //KATEGORIJE
    public static final String DATABASE_TABLE_KATEGORIJA = "Kategorije";
    public static final String ID_IKONICE = "id_ikonice";
    public static final String KATEGORIJA_NAZIV = "naziv";

    //PITANJA
    public static final String DATABASE_TABLE_PITANJA = "Pitanja";
    public static final String INDEX_TACNOG = "indexTacnog";
    public static final String ODGOVORI= "odgovori";
    public static final String PITANJA_NAZIV= "naziv";


    SQLiteDatabase db = getWritableDatabase();

    private static final String CREATE_TABLE_KATEGORIJA = "CREATE TABLE " + DATABASE_TABLE_KATEGORIJA + " (" +
            ID_IKONICE + " TEXT, " +
            KATEGORIJA_NAZIV + " TEXT PRIMARY KEY  );";


    private static final String CREATE_TABLE_PITANJA = "CREATE TABLE " + DATABASE_TABLE_PITANJA + " (" +
            INDEX_TACNOG + " TEXT, " +
            ODGOVORI + " TEXT, " +
            PITANJA_NAZIV + " TEXT PRIMARY KEY  );";


    public BazaOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_KATEGORIJA);
        db.execSQL(CREATE_TABLE_PITANJA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_KATEGORIJA);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_PITANJA);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db){
        super.onOpen(db);
    }

//KATEGORIJA
    public long dodajKategoriju(String naziv, String idIkonice) throws Exception{
        long vrati;
        ContentValues values = new ContentValues();
        values.put(KATEGORIJA_NAZIV,naziv);
        values.put(ID_IKONICE,idIkonice);
        try{
            vrati = db.insertOrThrow(DATABASE_TABLE_KATEGORIJA, null, values);
        }catch (SQLiteConstraintException e){
            return -1;
        }
        return vrati;
    }

    public ArrayList<Kategorija> dajKategorije() throws Exception{
        ArrayList<Kategorija> unosi = new ArrayList<>();
        try{
            Cursor cur = db.rawQuery("SELECT * FROM "+ DATABASE_TABLE_KATEGORIJA,null);
            if(cur.getCount() == 0) return unosi;
            if (cur.getCount() > 0) {
                while (cur.moveToNext()) {
                    Kategorija temp = new Kategorija(cur.getString(1),cur.getString(0));
                    unosi.add(temp);
                }
            }
            cur.close();
            return unosi;
        } catch(SQLiteException e){
            return unosi;
        }
    }
//PITANJA
    public long dodajPitanje(String indexTacnog, String odgovori, String naziv) throws Exception{
        long vrati;
        ContentValues values = new ContentValues();
        values.put(INDEX_TACNOG,indexTacnog);
        values.put(ODGOVORI,odgovori);
        values.put(PITANJA_NAZIV,naziv);
        try{
            Log.e("A","DOSAO");
            vrati = db.insertOrThrow(DATABASE_TABLE_PITANJA, null, values);
        }catch (SQLiteConstraintException e){
            return -1;
        }
        return vrati;
    }

    public ArrayList<Pitanje> dajPitanja() throws Exception{
        ArrayList<Pitanje> unosi = new ArrayList<>();
        try{
            Cursor cur = db.rawQuery("SELECT * FROM "+ DATABASE_TABLE_PITANJA,null);
            if(cur.getCount() == 0) return unosi;
            if (cur.getCount() > 0) {
                while (cur.moveToNext()) {
                    ArrayList<String> tempic = dajOdgovoreIzStringa(cur.getString(1));
                    Pitanje temp = new Pitanje(cur.getString(2),cur.getString(2),tempic,cur.getString(0));
                    unosi.add(temp);
                }
            }
            cur.close();
            return unosi;
        } catch(SQLiteException e){
            return unosi;
        }
    }







//AHOLE funkcije
    public static String dajStringIzOdgovora(ArrayList<String> odgovori){
        String vrati = "";
        for(int i=0; i<odgovori.size(); i++){
            if(i == odgovori.size()-1) vrati += "" + odgovori.get(i);
            else vrati += "" + odgovori.get(i) + ",";
        }
        return vrati;
    }

    public static ArrayList<String> dajOdgovoreIzStringa(String odgovori){
        ArrayList<String> vrati = new ArrayList<>();
        String[] x = odgovori.split(",");
        for(int i = 0; i<x.length; i++){
            vrati.add(x[i]);
        }
        return vrati;
    }
}
