package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.provider.AlarmClock;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.FrameLayout;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.Kviz;

import static java.time.ZoneOffset.UTC;

public class IgrajKvizAkt extends AppCompatActivity implements InformacijeFrag.klikBtnKraj, PitanjeFrag.odgovorioPitanje{
    AlarmClock alarmClock;

    EditText txtUrl;
    String test = "";
    RangLista rangLista;

    Kviz kviz;
    FragmentManager fragmentManager;
    InformacijeFrag informacijeFrag;
    PitanjeFrag pitanjeFrag;
    public static Context context;

    ArrayList<Integer> info;
    int brojTacnih = 0;
    int brojOdgovorenih = 0;
    int brojPreostalih;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);
        context = this;
        txtUrl = new EditText(this);
        kviz = (Kviz) getIntent().getBundleExtra("Bundle").getSerializable("Kviz");
        postaviAlarmClock();
        info = new ArrayList<>();
        info.add(0);
        info.add(0);
        info.add(kviz.getPitanja().size()-1);



        fragmentManager = getSupportFragmentManager();
        FrameLayout informacijePlace = (FrameLayout)findViewById(R.id.informacijePlace);
        FrameLayout pitanjePlace = (FrameLayout)findViewById(R.id.pitanjePlace);



        Bundle argumenti = new Bundle();
        argumenti.putSerializable("Kviz",kviz);
        argumenti.putIntegerArrayList("Informacije",info);

        if(informacijePlace != null && pitanjePlace  != null){
            informacijeFrag = new InformacijeFrag();
            pitanjeFrag = new PitanjeFrag();
            informacijeFrag.setArguments(argumenti);
            pitanjeFrag.setArguments(argumenti);
            fragmentManager.beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
            fragmentManager.beginTransaction().replace(R.id.pitanjePlace, pitanjeFrag).commit();
        }

    }

    @Override
    public void klik() {
        Intent intent = new Intent();
        setResult(601, intent);
        finish();
    }

    @Override
    public void odgovorio(Boolean x) {
        brojOdgovorenih++;
        info.set(1,info.get(1)+1);
        if(x){
            info.set(0,info.get(0)+1);
        }
        info.set(2,info.get(2)-1);

        Bundle argumenti = new Bundle();
        argumenti.putSerializable("Kviz",kviz);
        argumenti.putIntegerArrayList("Informacije",info);
        FrameLayout informacijePlace = (FrameLayout)findViewById(R.id.informacijePlace);
        if(informacijePlace != null){
            informacijeFrag = new InformacijeFrag();
            informacijeFrag.setArguments(argumenti);
            fragmentManager.beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
        }
        if(kviz.getPitanja().size() == brojOdgovorenih){
            new AlertDialog.Builder(this)
                    .setTitle("Unos za rang listu")
                    .setMessage("Molimo unesite svoje ime!")
                    .setView(txtUrl)
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            test = txtUrl.getText().toString();
                            if(test.equals("")){
                                test = "Unknown";
                            }
                            //Log.e("Ovdje","Ime korisnika: " + test +" Ime kviza " + kviz.getNaziv() + "Info " + (info.get(0)*100.0/info.get(1)) );

                            rangLista = new RangLista();
                            Bundle argumenti = new Bundle();
                            argumenti.putString("ImeIgraca", test);
                            argumenti.putString("ImeKviza",kviz.getNaziv());
                            argumenti.putDouble("Procenat",(info.get(0)*100.0/info.get(1)));
                            rangLista.setArguments(argumenti);
                            fragmentManager.beginTransaction().replace(R.id.pitanjePlace, rangLista).commit();
                        }
                    })
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();

            //return;
        }

    }
    public void postaviAlarmClock(){
        int brojP = kviz.getPitanja().size();
        if(brojP%2==1) brojP++;
        brojP /= 2;



        Date date = new Date();
        Calendar calendar = GregorianCalendar.getInstance();
        calendar.setTime(date);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE) + brojP;

        if(minute > 60){
            hour += 1;
            minute -=60;
            if(hour > 23) hour-=24;
        }
        Log.e("Hours and min for alarm", " " + hour + " " + minute);
        Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
        intent.putExtra(AlarmClock.EXTRA_MESSAGE,"Kraj kviza");
        intent.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        intent.putExtra(AlarmClock.EXTRA_HOUR,hour);
        intent.putExtra(AlarmClock.EXTRA_MINUTES,minute);
        startActivity(intent);
    }
}
