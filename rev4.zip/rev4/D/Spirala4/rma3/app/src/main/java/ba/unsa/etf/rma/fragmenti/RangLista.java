package ba.unsa.etf.rma.fragmenti;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.asyncKlase.DohvatiRangListu;
import ba.unsa.etf.rma.asyncKlase.PostajRangList;

/**
 * A simple {@link Fragment} subclass.
 */
public class RangLista extends Fragment implements PostajRangList.IPostajRangList, DohvatiRangListu.IDohvatiRangListu {
    String imeIgraca;
    String imeKviza;
    Double Procenat;

    ArrayList<String> igraci;
    ArrayList<String> procentiTacnih;
    ArrayList<String> mjestoIgraca = new ArrayList<>();

    ListView rangListaView;
    public RangLista() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_rang_lista, container, false);
    }
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        rangListaView = getView().findViewById(R.id.rangListaView);
        imeIgraca = (String) getArguments().getString("ImeIgraca");
        imeKviza = (String) getArguments().getString("ImeKviza");
        Procenat = (Double) getArguments().getDouble("Procenat");
        odradiSvojPosao();

    }

    public void odradiSvojPosao(){
        new PostajRangList(RangLista.this).execute(Procenat.toString(),imeIgraca, imeKviza);
    }

    @Override
    public void onPostajRangList() {
        new DohvatiRangListu(RangLista.this).execute(imeKviza);
    }

    @Override
    public void onDohvatiRangListu(ArrayList<String> rezultat, ArrayList<String> procenti) {
        igraci = rezultat;
        procentiTacnih = procenti;
        for(int i=0; i<procentiTacnih.size()-1; i++){
            for(int j=0; j<procentiTacnih.size()-i-1; j++){
                if((Double.parseDouble(procentiTacnih.get(j))- Double.parseDouble(procentiTacnih.get(j+1)) ) < 0.1){
                    String x = procentiTacnih.get(j);
                    procentiTacnih.set(j, procentiTacnih.get(j+1));
                    procentiTacnih.set(j+1, x);

                    String y = igraci.get(j);
                    igraci.set(j, igraci.get(j+1));
                    igraci.set(j+1, y);
                }
            }
        }
        for(int i=0; i<procentiTacnih.size(); i++){
            mjestoIgraca.add("" + (i+1) + ".   " + igraci.get(i) + "  " + procentiTacnih.get(i) + "%");
        }
        rangListaView.setAdapter(new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,mjestoIgraca));
    }
}
