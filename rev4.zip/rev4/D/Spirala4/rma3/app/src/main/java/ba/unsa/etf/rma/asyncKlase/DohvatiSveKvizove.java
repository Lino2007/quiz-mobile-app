package ba.unsa.etf.rma.asyncKlase;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajKategorijuAkt;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DohvatiSveKvizove extends AsyncTask<String, Void, Void> implements DohvatiSveKategorije.IDohvatiKategorije{

    ArrayList<Kviz> rezultatAsyncKlase = new ArrayList<>();
    ArrayList<Kategorija> kategorije = new ArrayList<>();
    private IDohvatiSveKvizove pozivatelj;

    public DohvatiSveKvizove(IDohvatiSveKvizove p){
        pozivatelj = p;
    }

    @Override
    protected Void doInBackground(String... strings){
        Context x;
        if(strings[0].equals("proba1"))x = KvizoviAkt.context;
        else if(strings[0].equals("proba2"))x = DodajKvizAkt.context;
        else x = DodajKategorijuAkt.context;
        new DohvatiSveKategorije((DohvatiSveKategorije.IDohvatiKategorije)x).execute("proba1");
        try {
            if(strings[0].equals("proba1"))x = KvizoviAkt.context;
            else if(strings[0].equals("proba2"))x = DodajKvizAkt.context;
            else x = DodajKategorijuAkt.context;
            InputStream is = x.getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();
            Log.e("Token", TOKEN);
            String url = "https://firestore.googleapis.com/v1/projects/rma-moj-projekat/databases/(default)/documents/Kvizovi?access_token=";
            URL urlConnection = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
            HttpURLConnection connection = (HttpURLConnection) urlConnection.openConnection();

            int responseCode = connection.getResponseCode();
            if(responseCode == HttpURLConnection.HTTP_OK){
                try(BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))){
                    StringBuilder res = new StringBuilder();
                    String line = null;
                    while((line = br.readLine()) != null){
                        res.append(line.trim());
                    }
                    //Odgovor od stranice pretvaramo u String
                    String rezultat = res.toString();
                    //Taj odgovor pretvaramo u JSON objekat
                    JSONObject jo = new JSONObject(rezultat);
                    //Prvi u formatu je documents koji je tipa Array
                    JSONArray jo_documents = jo.getJSONArray("documents");
                    //Sljedeci u formatu je name koji je tipa Object ali posto imamo array moramo for petljom dobavljati sve objekte
                    ArrayList<Kviz> kvizovis = new ArrayList<>();
                    for(int i = 0; i<jo_documents.length(); i++){
                        JSONObject jo_Kategorija = jo_documents.getJSONObject(i);
                        JSONObject jo_fields = jo_Kategorija.getJSONObject("fields");
                        JSONObject jo_naziv = jo_fields.getJSONObject("naziv");
                        JSONObject jo_idKategorije = jo_fields.getJSONObject("idKategorije");
                        String naziv = jo_naziv.get("stringValue").toString();
                        String idKategorije = jo_idKategorije.get("stringValue").toString();
                        Kategorija kat = new Kategorija(idKategorije,"22");
                        for(int j=0; i< kategorije.size(); i++){
                            if(kategorije.get(j).getNaziv().equals(idKategorije)) kat=kategorije.get(j);
                        }
                        Kviz Novi = new Kviz(naziv,new ArrayList<Pitanje>(),kat);
                        kvizovis.add(Novi);
                    }
                    rezultatAsyncKlase = kvizovis;

                }finally {
                    connection.disconnect();
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void onDohvatiKategorijeDone(ArrayList<Kategorija> rezultat) {
        kategorije = rezultat;
    }

    public interface IDohvatiSveKvizove{
        public void onDohvatiSveKvizove(ArrayList<Kviz> rezultat);
    }

    @Override
    protected void onPostExecute(Void aVoid){
        super.onPostExecute(aVoid);
        pozivatelj.onDohvatiSveKvizove(rezultatAsyncKlase);
    }

}