package ba.unsa.etf.rma.aktivnosti;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.KvizAdapter;
import ba.unsa.etf.rma.asyncKlase.DohvatiKvizoveSaKategorijom;
import ba.unsa.etf.rma.asyncKlase.DohvatiSveKategorije;
import ba.unsa.etf.rma.asyncKlase.DohvatiSveKvizove;
import ba.unsa.etf.rma.baza.BazaOpenHelper;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizoviAkt extends AppCompatActivity implements DohvatiSveKategorije.IDohvatiKategorije, DohvatiSveKvizove.IDohvatiSveKvizove,
        DohvatiKvizoveSaKategorijom.IDohvatiKvizoveSaKategorijom {
    BazaOpenHelper bdb;
    public static Boolean imaInternet = false;

    public static Context context;
    Spinner spPostojeceKategorije;
    ListView lvKvizovi;
    ArrayList<Kategorija> kategorija;
    ArrayList<Pitanje> pitanje;
    ArrayList<Kviz> kviz;
    ArrayList<Kviz> filtrirane;
    Kviz univerzalni = new Kviz("Dodaj Kviz",new Kategorija("DodajKviz","DodajKviz666"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kvizovi_akt);
        context = this;
        daLiImaInterneta();
        bdb = new BazaOpenHelper(this);
        try {
            bdb.dodajKategoriju("Meri","22");
            ArrayList<String> odg = new ArrayList<>();
            odg.add("Tacan");
            odg.add("Nije tacan");
            Pitanje x = new Pitanje("Meri","Meri",odg,"0");
            String odg_string = BazaOpenHelper.dajStringIzOdgovora(odg);
            bdb.dodajPitanje(x.getTacan(),odg_string,x.getNaziv());


            ArrayList<Kategorija> daVidimo = bdb.dajKategorije();
            ArrayList<Pitanje> daVidimo1 = bdb.dajPitanja();
            Log.e("Test", "Baza radi!");
            Log.e("TT", "Size " + daVidimo.size() + " Item dodani: " + daVidimo.get(0).getNaziv() + daVidimo.get(0).getId());
            Log.e("TT", "Size " + daVidimo1.size() + " Item dodani: " + daVidimo1.get(0).getNaziv() + daVidimo1.get(0).getTacan() + daVidimo1.get(0).getOdgovori().get(0));
        } catch (Exception e) {
            e.printStackTrace();
        }
        //SPIRALA 3
        new DohvatiSveKvizove(KvizoviAkt.this).execute("proba1");
        new DohvatiSveKategorije((DohvatiSveKategorije.IDohvatiKategorije)KvizoviAkt.this).execute("proba1");
        //Activity_kvizovi_akt.xml povezivanje elemenata sa programom
        spPostojeceKategorije = findViewById(R.id.spPostojeceKategorije);
        lvKvizovi = findViewById(R.id.lvKvizovi);

        //Incijaliziranje i stavljanje adaptera
        kategorija = new ArrayList<>();
        kategorija.add(new Kategorija("Svi", "0"));
        spPostojeceKategorije.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,dajSveKategorije(kategorija)));
        pitanje = new ArrayList<>();
        kviz = new ArrayList<>();



        lvKvizovi.setAdapter(new KvizAdapter(this,R.layout.list_kviz_element,dajKvizoveKategorije("Svi")));
        //Mjenjanje kategorije u spineru i filtriranje u listView
        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i>=0 && i<kategorija.size()){
                    pretraziKvizove(i);
                }
                else{
                    Toast.makeText(KvizoviAkt.this, "Nema Kategorije", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                /*
                */
                if(i == dajKvizoveKategorije(spPostojeceKategorije.getSelectedItem().toString()).size()-1){
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("Kviz", univerzalni);
                    bundle.putSerializable("Kategorije",kategorija);
                    bundle.putSerializable("Pitanja",pitanje);
                    bundle.putSerializable("Kvizovi",kviz);
                    Intent intent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                    intent.putExtra("Bundle",bundle);
                    startActivityForResult(intent,102);
                }
                else{
                    if(DaLiImaVremenaZaKviz(kviz.get(i).getPitanja().size())){
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("Kviz", kviz.get(i));
                        Intent intent = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                        intent.putExtra("Bundle",bundle);
                        startActivityForResult(intent,106);
                    }
                    else{
                        new AlertDialog.Builder(KvizoviAkt.this)
                                .setTitle("Warning")
                                .setMessage("Nije preostalo dovoljno vremena za kviz, imate vec Event!")
                                .setPositiveButton(android.R.string.yes, null)
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();
                    }
                }
                /*
                */
                /*
                Bundle bundle = new Bundle();
                bundle.putSerializable("Kviz", kviz.get(i));
                bundle.putSerializable("Kategorije",kategorija);
                bundle.putSerializable("Pitanja",pitanje);
                bundle.putSerializable("Kvizovi",kviz);
                Intent intent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                intent.putExtra("Bundle",bundle);
                startActivityForResult(intent,102);
                 */
            }
        });

        lvKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Bundle bundle = new Bundle();
                if(i == dajKvizoveKategorije(spPostojeceKategorije.getSelectedItem().toString()).size()-1)bundle.putSerializable("Kviz", univerzalni);
                else bundle.putSerializable("Kviz", kviz.get(i));
                bundle.putSerializable("Kategorije",kategorija);
                bundle.putSerializable("Pitanja",pitanje);
                bundle.putSerializable("Kvizovi",kviz);
                Intent intent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                intent.putExtra("Bundle",bundle);
                startActivityForResult(intent,102);
                return true;
            }
        });
    }
    //FUNKCIJE
    public ArrayList<String> dajSveKategorije(ArrayList<Kategorija> x){
        ArrayList<String> sveKategorije = new ArrayList<>();
        for(int i=0; i<x.size(); i++){
            sveKategorije.add(x.get(i).getNaziv());
        }
        return sveKategorije;
    }


    public ArrayList<Kviz> dajKvizoveKategorije(String x){
        ArrayList<Kviz> sviKvizoviKategorije = new ArrayList<>();
        Kategorija tempKategorija = new Kategorija("Greska","-987654321");
        for(int i=0; i<kategorija.size(); i++){
            if(kategorija.get(i).getNaziv().equals(x)){
                tempKategorija = kategorija.get(i);
                break;
            }
        }
        if(tempKategorija.getId().equals("0")){
            for(int i=0; i<kviz.size(); i++){
                sviKvizoviKategorije.add(kviz.get(i));
            }
        }
        else{
            for(int i=0; i<kviz.size(); i++){
                if(kviz.get(i).getKategorija().getNaziv().equals(tempKategorija.getNaziv())
                        && kviz.get(i).getKategorija().getId().equals(tempKategorija.getId())){
                    sviKvizoviKategorije.add(kviz.get(i));
                }
            }
        }
        sviKvizoviKategorije.add(univerzalni);
        for(int i=0; i<sviKvizoviKategorije.size(); i++);
        //kviz.add(univerzalni);
        return sviKvizoviKategorije;

    }

    public void pretraziKvizove(int i){
        ArrayList<String> kategorijeString = dajSveKategorije(kategorija);
        String tempKategorijaString = kategorijeString.get(i);
        new DohvatiKvizoveSaKategorijom((DohvatiKvizoveSaKategorijom.IDohvatiKvizoveSaKategorijom)KvizoviAkt.this).execute(tempKategorijaString);
        //filtrirane = dajKvizoveKategorije(tempKategorijaString);
        //lvKvizovi.setAdapter(new KvizAdapter(this,R.layout.list_kviz_element,filtrirane));

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Check which request we're responding to
        /*
        if (resultCode == 201) {
            kviz = (ArrayList<Kviz>) data.getBundleExtra("Bundle").getSerializable("Kvizovi");
            kategorija = (ArrayList<Kategorija>) data.getBundleExtra("Bundle").getSerializable("Kategorije");
            pitanje = (ArrayList<Pitanje>) data.getBundleExtra("Bundle").getSerializable("Pitanja");
            spPostojeceKategorije.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,dajSveKategorije(kategorija)));
            lvKvizovi.setAdapter(new KvizAdapter(this,R.layout.list_kviz_element,dajKvizoveKategorije("Svi")));
        }
        */
        new DohvatiSveKategorije((DohvatiSveKategorije.IDohvatiKategorije)KvizoviAkt.this).execute("proba1");
        new DohvatiSveKvizove(KvizoviAkt.this).execute("proba1");
    }

    @Override
    public void onDohvatiKategorijeDone(ArrayList<Kategorija> rezultat) {
        kategorija = new ArrayList<>();
        kategorija.add(new Kategorija("Svi", "0"));
        for(int i=0; i<rezultat.size(); i++){
            kategorija.add(rezultat.get(i));
        }
        spPostojeceKategorije.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,dajSveKategorije(kategorija)));
    }

    @Override
    public void onDohvatiSveKvizove(ArrayList<Kviz> rezultat) {
        kviz = rezultat;
        lvKvizovi.setAdapter(new KvizAdapter(this,R.layout.list_kviz_element,dajKvizoveKategorije("Svi")));
    }

    @Override
    public void onDohvatiKvizoveSaKategorijom(ArrayList<Kviz> rezultat) {
        kviz = rezultat;
        lvKvizovi.setAdapter(new KvizAdapter(this,R.layout.list_kviz_element,dajKvizoveKategorije("Svi")));
    }

    public boolean DaLiImaVremenaZaKviz(int x){
        int minute = x;
        if(minute%2==1) minute +=1;
        minute /=2;
        int test = ReadCalendar(minute);
        if(minute < test){
            return true;
        }else{
            return false;
        }
    }

    public int ReadCalendar(int min){
        String[] projection = new String[]{CalendarContract.Events.CALENDAR_ID, CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART};
        long MIN_IN_MS = 60000;

        Calendar date = Calendar.getInstance();
        long vrijemeSaTrajanjemKviza = date.getTimeInMillis() + (min * MIN_IN_MS);
        String selection = "(( " + CalendarContract.Events.DTSTART + " >= " + date.getTimeInMillis() + " )" +
                " AND (" + CalendarContract.Events.DTSTART + "<=" + vrijemeSaTrajanjemKviza + "))";

        if (ContextCompat.checkSelfPermission(KvizoviAkt.this,Manifest.permission.READ_CALENDAR)!= PackageManager.PERMISSION_GRANTED){
            if (ActivityCompat.shouldShowRequestPermissionRationale(KvizoviAkt.this,Manifest.permission.READ_CALENDAR)) {
                Cursor cursor = this.getBaseContext().getContentResolver().query(CalendarContract.Events.CONTENT_URI, projection, selection, null, null);
                if (cursor != null) {
                    if (cursor.moveToFirst()) {
                        String title = cursor.getString(1);
                        long minLeft;
                        Date date1 = new Date(cursor.getLong(2));
                        Date proslo = new Date(date.getTimeInMillis());
                        minLeft = date1.getTime() - proslo.getTime();
                        int xyz = ((int) minLeft / 60000);
                        Log.e("Title", title);
                        Log.e("Y", "Min Left " + xyz);

                        return xyz;
                    }

                }
                return 999;
            } else {
                ActivityCompat.requestPermissions(KvizoviAkt.this,new String[]{Manifest.permission.READ_CALENDAR},3000);
                Cursor cursor = this.getBaseContext().getContentResolver().query(CalendarContract.Events.CONTENT_URI, projection, selection, null, null);
                if (cursor != null) {
                    if (cursor.moveToFirst()) {
                        String title = cursor.getString(1);
                        long minLeft;
                        Date date1 = new Date(cursor.getLong(2));
                        Date proslo = new Date(date.getTimeInMillis());
                        minLeft = date1.getTime() - proslo.getTime();
                        int xyz = ((int) minLeft / 60000);
                        Log.e("Title", title);
                        Log.e("Y", "Min Left " + xyz);

                        return xyz;
                    }

                }
            }

            return 999;
        }
        else{
            Cursor cursor = this.getBaseContext().getContentResolver().query(CalendarContract.Events.CONTENT_URI, projection, selection, null, null);
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    String title = cursor.getString(1);
                    long minLeft;
                    Date date1 = new Date(cursor.getLong(2));
                    Date proslo = new Date(date.getTimeInMillis());
                    minLeft = date1.getTime() - proslo.getTime();
                    int xyz = ((int) minLeft / 60000);
                    Log.e("Title", title);
                    Log.e("Y", "Min Left " + xyz);

                    return xyz;
                }

            }
        }
        return 999;
    }

    public void daLiImaInterneta(){
        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            imaInternet = true;
        }
        else
            imaInternet = false;

    }
}
