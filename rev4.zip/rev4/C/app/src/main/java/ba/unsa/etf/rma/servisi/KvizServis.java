package ba.unsa.etf.rma.servisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Konverzija;
import ba.unsa.etf.rma.klase.Kviz;

public class KvizServis extends IntentService{

    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;
    Bundle bundle = new Bundle();

    public KvizServis() {
        super(null);
    }
    public KvizServis(String name) {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }
    @Override
    public void onCreate() {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }
    @Override
    protected void onHandleIntent(Intent intent) {

        final ResultReceiver resultReceiver = intent.getParcelableExtra("RISIVER");
        Kviz kviz = intent.getParcelableExtra("KVIZ");
        Kviz kvizZaBrisanjeIzBaze = intent.getParcelableExtra("KVIZBRISANJE");
        boolean update = intent.getBooleanExtra("UPDATE",false);

        try {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();
            Log.d("TOKEN", TOKEN);

            URL urlObj;
            HttpURLConnection urlConnection;
            String nazivKviza = URLEncoder.encode(kviz.getNaziv(),"utf-8");

            if(kvizZaBrisanjeIzBaze!=null || !update){
                //mora se izbrisati jer id je naziv kviza, brise se pa dodaje samo ako se promijeni naziv, u suprotonom se sa patch edituje
                if(kvizZaBrisanjeIzBaze!=null) {
                    String nazivKvizaZaBisanje = URLEncoder.encode(kvizZaBrisanjeIzBaze.getNaziv(), "utf-8");
                    try {
                        String urlBrisanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kvizovi/" + nazivKvizaZaBisanje + "?currentDocument.exists=true&access_token=";
                        urlObj = new URL(urlBrisanje + URLEncoder.encode(TOKEN, "UTF-8"));
                        urlConnection = (HttpURLConnection) urlObj.openConnection();
                        urlConnection.setDoOutput(true);
                        urlConnection.setRequestMethod("DELETE");
                        urlConnection.setRequestProperty("Content-Type", "application/json");
                        urlConnection.setRequestProperty("Accept", "application/json");

                        int responseCode = urlConnection.getResponseCode();
                        Log.d("BRISANJE", "IZBRISAN");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try{
                    String urlDohvatanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kvizovi/" + nazivKviza + "?access_token=";
                    urlObj = new URL(urlDohvatanje + URLEncoder.encode(TOKEN, "UTF-8"));
                    urlConnection = (HttpURLConnection) urlObj.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.setRequestProperty("Content-Type", "application/json");
                    urlConnection.setRequestProperty("Accept", "application/json");

                    InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                    String rezultat = Konverzija.convertStreamToString(in);
                    JSONObject jo = new JSONObject(rezultat);
                    //znaci postoji u bazi
                    kviz=null;
                    bundle.putString("AlertDialog","");

                }
                catch (FileNotFoundException | JSONException e){
                    String urlUploadanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kvizovi/" + nazivKviza + "?currentDocument.exists=false&access_token=";
                    urlObj = new URL(urlUploadanje + URLEncoder.encode(TOKEN,"UTF-8"));
                    urlConnection = (HttpURLConnection) urlObj.openConnection();
                    urlConnection.setDoOutput(true);
                    urlConnection.setRequestMethod("PATCH");
                    urlConnection.setRequestProperty("Content-Type", "application/json");
                    urlConnection.setRequestProperty("Accept", "application/json");

                    String jsonPitanja = "";
                    for (int i = 0; i < kviz.getPitanja().size(); i++){
                        jsonPitanja += "{\"stringValue\": \"" + kviz.getPitanja().get(i).getNaziv() + "\"}";
                        if(i!=kviz.getPitanja().size()-1) jsonPitanja += ",";
                    }
                    String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\": \"" + kviz.getNaziv() + "\"}, \"idKategorije\": {\"stringValue\": \"" + kviz.getKategorija().getNaziv() + "\"}, \"pitanja\": {\"arrayValue\": {\"values\": [" + jsonPitanja + "]}}}}";


                    try(OutputStream os = urlConnection.getOutputStream()){
                        byte[] input = dokument.getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }
                    int code = urlConnection.getResponseCode();
                    InputStream odgovor = urlConnection.getInputStream();
                    try(BufferedReader br = new BufferedReader(
                            new InputStreamReader(odgovor, "utf-8"))){
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while((responseLine = br.readLine()) != null){
                            response.append(responseLine.trim());
                        }
                        Log.d("ODGOVOR", response.toString());
                    }
                }
            }
            else if(update && kvizZaBrisanjeIzBaze==null){
                boolean postoji = false;
                try{
                    try {
                        //provjera jel postoji u bazi taj koji se apdejtuje, ako ne dodaje se
                        String urlDohvatanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kvizovi/" + nazivKviza + "?access_token=";
                        urlObj = new URL(urlDohvatanje + URLEncoder.encode(TOKEN, "UTF-8"));
                        urlConnection = (HttpURLConnection) urlObj.openConnection();
                        urlConnection.setRequestMethod("GET");
                        urlConnection.setRequestProperty("Content-Type", "application/json");
                        urlConnection.setRequestProperty("Accept", "application/json");

                        InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                        String rezultat = Konverzija.convertStreamToString(in);
                        JSONObject jo = new JSONObject(rezultat);
                        //znaci postoji u bazi

                        postoji = true;
                    }
                    catch (FileNotFoundException e){
                        e.printStackTrace();
                    }

                    String urlUploadanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kvizovi/" + nazivKviza + "?currentDocument.exists=" + postoji + "&access_token=";
                    urlObj = new URL(urlUploadanje + URLEncoder.encode(TOKEN,"UTF-8"));
                    urlConnection = (HttpURLConnection) urlObj.openConnection();
                    urlConnection.setDoOutput(true);
                    urlConnection.setRequestMethod("PATCH");
                    urlConnection.setRequestProperty("Content-Type", "application/json");
                    urlConnection.setRequestProperty("Accept", "application/json");

                    String jsonPitanja = "";
                    for (int i = 0; i < kviz.getPitanja().size(); i++){
                        jsonPitanja += "{\"stringValue\": \"" + kviz.getPitanja().get(i).getNaziv() + "\"}";
                        if(i!=kviz.getPitanja().size()-1) jsonPitanja += ",";
                    }
                    String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\": \"" + kviz.getNaziv() + "\"}, \"idKategorije\": {\"stringValue\": \"" + kviz.getKategorija().getNaziv() + "\"}, \"pitanja\": {\"arrayValue\": {\"values\": [" + jsonPitanja + "]}}}}";


                    try(OutputStream os = urlConnection.getOutputStream()){
                        byte[] input = dokument.getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }
                    int code = urlConnection.getResponseCode();
                    InputStream odgovor = urlConnection.getInputStream();
                    try(BufferedReader br = new BufferedReader(
                            new InputStreamReader(odgovor, "utf-8"))){
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while((responseLine = br.readLine()) != null){
                            response.append(responseLine.trim());
                        }
                        Log.d("ODGOVOR", response.toString());
                    }

                }
                catch (JSONException e){
                    e.printStackTrace();
                }

            }
            bundle.putParcelable("KVIZ", kviz);
            bundle.putBoolean("UPDATE", update);
            resultReceiver.send(STATUS_FINISHED,bundle);
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}
