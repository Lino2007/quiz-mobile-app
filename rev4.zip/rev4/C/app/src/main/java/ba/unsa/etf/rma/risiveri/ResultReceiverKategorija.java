package ba.unsa.etf.rma.risiveri;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

public class ResultReceiverKategorija extends ResultReceiver {

    private ReceiverKategorija mReceiver;
    public ResultReceiverKategorija(Handler handler) {
        super(handler);
    }
    public void setReceiver(ReceiverKategorija receiver) {
        mReceiver = receiver;
    }
    /* Deklaracija interfejsa koji će se trebati implementirati */
    public interface ReceiverKategorija {
        public void onReceiveResultKategorija(int resultCode, Bundle resultData);
    }
    @Override
    protected void onReceiveResult(int resultCode, Bundle resultData) {
        if (mReceiver != null) {
            mReceiver.onReceiveResultKategorija(resultCode, resultData);
        }
    }
}
