package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class GridAdapter extends ArrayAdapter<Kviz> {
    public GridAdapter(Context context, ArrayList<Kviz> users) {
        super(context, 0, users);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Kviz kviz = getItem(position);
        if (convertView == null) {
            if(kviz.getNaziv().equals("Dodaj kviz")){
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.grid_item_dodaj_kviz, parent, false);
            }
            else convertView = LayoutInflater.from(getContext()).inflate(R.layout.grid_item, parent, false);
        }
        TextView imeKviza = (TextView) convertView.findViewById(R.id.imeKviza);
        if(imeKviza!=null) {
            imeKviza.setText(kviz.getNaziv());
            TextView brojPitanja = (TextView) convertView.findViewById(R.id.brojPitanja);
            brojPitanja.setText(String.valueOf(kviz.getPitanja().size()));
            final ImageView slikaKategorije = (ImageView) convertView.findViewById(R.id.slikaKategorije);
            final IconHelper iconHelper = IconHelper.getInstance(convertView.getContext());
            iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
                @Override
                public void onDataLoaded() {
                    slikaKategorije.setImageDrawable(iconHelper.getIcon(Integer.parseInt(kviz.getKategorija().getId())).getDrawable(getContext()));
                }
            });
        }
        return convertView;
    }
}
