package ba.unsa.etf.rma.servisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Konverzija;
import ba.unsa.etf.rma.klase.Pitanje;

public class KategorijeServis extends IntentService {

    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;

    public KategorijeServis() {
        super(null);
    }
    public KategorijeServis(String name) {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }
    @Override
    public void onCreate() {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }
    @Override
    protected void onHandleIntent(Intent intent) {

        final ResultReceiver resultReceiver = intent.getParcelableExtra("RISIVER");
        ArrayList<Kategorija> kategorije = new ArrayList<>();
        try {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();
            Log.d("TOKEN", TOKEN);

            URL urlObj;
            HttpURLConnection urlConnection;

            String urlSvi;
            try{
                urlSvi = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kategorije/Svi?access_token=";
                urlObj = new URL(urlSvi + URLEncoder.encode(TOKEN, "UTF-8"));
                urlConnection = (HttpURLConnection) urlObj.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.setRequestProperty("Accept", "application/json");

                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = Konverzija.convertStreamToString(in);
            }
            catch(FileNotFoundException ex){
                urlSvi = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kategorije?documentId=Svi&access_token=";
                urlObj = new URL(urlSvi + URLEncoder.encode(TOKEN,"UTF-8"));
                urlConnection = (HttpURLConnection) urlObj.openConnection();
                urlConnection.setDoOutput(true);
                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.setRequestProperty("Accept", "application/json");

                String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\": \"Svi\"}, \"idIkonice\": {\"integerValue\": \"5\"}}}";
                try(OutputStream os = urlConnection.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                int code = urlConnection.getResponseCode();
                InputStream odgovor = urlConnection.getInputStream();
                try(BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }

            }
                String urlDohvatanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kategorije?access_token=";
                urlObj = new URL(urlDohvatanje + URLEncoder.encode(TOKEN, "UTF-8"));
                urlConnection = (HttpURLConnection) urlObj.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.setRequestProperty("Accept", "application/json");

                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = Konverzija.convertStreamToString(in);
                JSONObject jo = new JSONObject(rezultat);

                JSONArray documents = jo.getJSONArray("documents");
                for(int i = 0; i < documents.length(); i++){
                    JSONObject kategorijaHelp = documents.getJSONObject(i);
                    JSONObject polja = kategorijaHelp.getJSONObject("fields");
                    JSONObject naziv = polja.getJSONObject("naziv");
                    String nazivKategorije = naziv.getString("stringValue");
                    JSONObject idIkoniceHelp = polja.getJSONObject("idIkonice");
                    int idIkonice = idIkoniceHelp.getInt("integerValue");

                    Kategorija kategorija = new Kategorija();
                    kategorija.setNaziv(nazivKategorije);
                    kategorija.setId(String.valueOf(idIkonice));

                    kategorije.add(kategorija);
                }
                Bundle bundle = new Bundle();
                bundle.putParcelableArrayList("KATEGORIJE", kategorije);
                resultReceiver.send(STATUS_FINISHED,bundle);
        }
        catch (IOException | JSONException e){
            e.printStackTrace();
        }
    }
}
