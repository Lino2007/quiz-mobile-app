package ba.unsa.etf.rma.klase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;
import android.util.Log;
import android.util.Pair;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kategorije;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kvizovi;

public class SQLBaza extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "baza.sqLiteDatabase";

    public static final String DATABASE_TABLE_KVIZOVI = "Kvizovi";
    public static final String KVIZ_ID = "_id";
    public static final String KVIZ_IDKATEGORIJE = "idKategorije";

    public static final String DATABASE_TABLE_KATEGORIJE = "Kategorije";
    public static final String KATEGORIJA_ID = "_id";
    public static final String KATEGORIJA_IDIKONICE = "idIkonice";

    public static final String DATABASE_TABLE_PITANJA = "Pitanja";
    public static final String PITANJE_ID = "_id";
    public static final String PITANJE_TACANODGOVOR = "tacanOdgovor";

    public static final String DATABASE_TABLE_ODGOVORI = "Odgovori";
    public static final String ODGOVOR_ID = "_id";

    public static final String DATABASE_TABLE_RANGLISTE = "Rangliste";
    public static final String RANGLISTA_ID = "_id";
    public static final String RANGLISTA_IGRAC = "igrac";
    public static final String RANGLISTA_REZULTAT = "ostvareniRezultat";
    public static final String RANGLISTA_IDKVIZA = "idKviza";

    public static final String DATABASE_TABLE_KVIZ_PITANJE = "KvizPitanje";
    public static final String KVIZ_PITANJE_IDKVIZA = "idKviza";
    public static final String KVIZ_PITANJE_IDPITANJA = "idPitanja";

    public static final String DATABASE_TABLE_ODGOVOR_PITANJE = "OdgovorPitanje";
    public static final String ODGOVOR_PITANJE_IDODGOVORA = "idOdgovora";
    public static final String ODGOVOR_PITANJE_IDPITANJA = "idPitanja";

    public static final int DATABASE_VERSION = 1;

    private static final String createTableKategorije = "CREATE TABLE " + DATABASE_TABLE_KATEGORIJE +
            " ( "+KATEGORIJA_ID+" TEXT PRIMARY KEY, "+
            KATEGORIJA_IDIKONICE + " TEXT NOT NULL );";

    private static final String createTableKvizovi = "CREATE TABLE " + DATABASE_TABLE_KVIZOVI +
            " ( "+KVIZ_ID+" TEXT PRIMARY KEY, " +
            KVIZ_IDKATEGORIJE + " INTEGER NOT NULL, " +
            "CONSTRAINT constr_tab_kvizovi_idkategorije FOREIGN KEY ( "+KVIZ_IDKATEGORIJE+") REFERENCES "+DATABASE_TABLE_KATEGORIJE+" ( "+ KATEGORIJA_ID+" ) );";

    private static final String createTableKvizPitanja = "CREATE TABLE " + DATABASE_TABLE_KVIZ_PITANJE +
            " ( "+KVIZ_PITANJE_IDKVIZA+" TEXT NOT NULL, "+
            KVIZ_PITANJE_IDPITANJA + " TEXT NOT NULL, " +
            "CONSTRAINT constr_tab_povezna_idkviza FOREIGN KEY ( "+KVIZ_PITANJE_IDKVIZA+") REFERENCES "+DATABASE_TABLE_KVIZOVI+" ( "+KVIZ_ID+" ), "+
            "CONSTRAINT constr_tab_povezna_idpitanja FOREIGN KEY ( "+KVIZ_PITANJE_IDPITANJA+") REFERENCES "+DATABASE_TABLE_PITANJA+" ( "+PITANJE_ID+" ) "
            +");";

    private static final String createTablePitanja = "CREATE TABLE " + DATABASE_TABLE_PITANJA +
            " ( "+PITANJE_ID+" TEXT PRIMARY KEY, " +
            PITANJE_TACANODGOVOR + " TEXT NOT NULL);";

    private static final String createTableOdgovori = "CREATE TABLE " + DATABASE_TABLE_ODGOVORI +
            " ( "+ODGOVOR_ID+" TEXT PRIMARY KEY);";

    private static final String createTableRangListe = "CREATE TABLE " + DATABASE_TABLE_RANGLISTE +
            " ( "+RANGLISTA_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
            RANGLISTA_IDKVIZA + " TEXT NOT NULL, "+
            RANGLISTA_REZULTAT + " REAL NOT NULL, "+
            RANGLISTA_IGRAC + " TEXT NOT NULL, " +
            " CONSTRAINT constr_tab_ranglista_idkviza FOREIGN KEY ( "+RANGLISTA_IDKVIZA+" ) REFERENCES "+DATABASE_TABLE_KVIZOVI+"("+KVIZ_ID+"), "+
            " CONSTRAINT constr_tab_ranglista_ostvarenirezultat CHECK ( "+RANGLISTA_REZULTAT+" BETWEEN 0 AND 1) );";

    private static final String createTableOdgovorPitanja = "CREATE TABLE " + DATABASE_TABLE_ODGOVOR_PITANJE +
            " ( "+ODGOVOR_PITANJE_IDODGOVORA+" TEXT NOT NULL, "+
            ODGOVOR_PITANJE_IDPITANJA + " TEXT NOT NULL, " +
            "CONSTRAINT constr_tab_povezna_idodgovora FOREIGN KEY ( "+ODGOVOR_PITANJE_IDODGOVORA+") REFERENCES "+DATABASE_TABLE_ODGOVORI+" ( "+ODGOVOR_ID+" ), "+
            "CONSTRAINT constr_tab_povezna_idpitanja FOREIGN KEY ( "+ODGOVOR_PITANJE_IDPITANJA+") REFERENCES "+DATABASE_TABLE_PITANJA+" ( "+PITANJE_ID+" ) "
            +");";


    public SQLBaza(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
    public SQLBaza(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL(createTableKvizovi);
        sqLiteDatabase.execSQL(createTableKategorije);
        sqLiteDatabase.execSQL(createTableKvizPitanja);
        sqLiteDatabase.execSQL(createTableOdgovori);
        sqLiteDatabase.execSQL(createTablePitanja);
        sqLiteDatabase.execSQL(createTableRangListe);
        sqLiteDatabase.execSQL(createTableOdgovorPitanja);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_RANGLISTE);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_ODGOVORI);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_KVIZ_PITANJE);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_PITANJA);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_KVIZOVI);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_KATEGORIJE);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_ODGOVOR_PITANJE);

        onCreate(sqLiteDatabase);
    }
    public boolean postojiKategorija(Kategorija kategorija){

        String query = "SELECT * " + "FROM " + DATABASE_TABLE_KATEGORIJE + " WHERE " + KATEGORIJA_ID + " = '" + kategorija.getNaziv() + "';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.getCount() > 0)
        {
            return true;
        }

        cursor.close();

        return false;
    }
    public void dodajKategoriju(Kategorija kategorija)
    {
        if(!postojiKategorija(kategorija)) {
            ContentValues contentValues = new ContentValues();

            contentValues.put(KATEGORIJA_ID, kategorija.getNaziv());
            contentValues.put(KATEGORIJA_IDIKONICE, kategorija.getId());

            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DATABASE_TABLE_KATEGORIJE, null, contentValues);
        }

    }
    public boolean postojiOdgovor(String odgovor){
        String query = "SELECT * " + "FROM " + DATABASE_TABLE_ODGOVORI + " WHERE " + ODGOVOR_ID + " = '" + odgovor + "';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.getCount() > 0)
        {
            return true;
        }

        cursor.close();

        return false;
    }
    //odg mogu biti isti tj. isti im je naziv u bazi zato je autoincrement id
    public void dodajOdgovor(String odgovor)
    {
        if(!postojiOdgovor(odgovor)) {

            ContentValues contentValues = new ContentValues();

            contentValues.put(ODGOVOR_ID, odgovor);

            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DATABASE_TABLE_ODGOVORI, null, contentValues);
        }
    }
    public boolean postojiPitanje(Pitanje pitanje){
        String query = "SELECT * "+
                "FROM "+DATABASE_TABLE_PITANJA+
                " WHERE " + PITANJE_ID + " = '" + pitanje.getNaziv() + "';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.getCount() > 0)
        {
            return true;
        }

        cursor.close();

        return false;
    }
    public void dodajPitanje(Pitanje pitanje){
        if(!postojiPitanje(pitanje))
        {
            ContentValues contentValues = new ContentValues();

            contentValues.put(PITANJE_ID, pitanje.getNaziv());
            contentValues.put(PITANJE_TACANODGOVOR, pitanje.getTacan());

            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DATABASE_TABLE_PITANJA, null, contentValues);

            for(int i=0; i<pitanje.getOdgovori().size(); i++){
                dodajOdgovor(pitanje.getOdgovori().get(i));
                dodajUOdgovorPitanje(pitanje, pitanje.getOdgovori().get(i));
            }
        }
    }
    public boolean postojiKviz(Kviz kviz){
        String query = "SELECT * "+
                "FROM "+DATABASE_TABLE_KVIZOVI+
                " WHERE " + KVIZ_ID + " = '" + kviz.getNaziv() + "';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.getCount() > 0)
        {
            return true;
        }

        cursor.close();

        return false;
    }
    public void dodajKviz(Kviz kviz){
        if(!postojiKviz(kviz)) {
            ContentValues contentValues = new ContentValues();

            contentValues.put(KVIZ_ID, kviz.getNaziv());
            contentValues.put(KVIZ_IDKATEGORIJE, kviz.getKategorija().getNaziv());

            for (int i = 0; i < kviz.getPitanja().size(); i++) {
                dodajPitanje(kviz.getPitanja().get(i));
                dodajUKvizPitanje(kviz, kviz.getPitanja().get(i));
            }

            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DATABASE_TABLE_KVIZOVI, null, contentValues);
        }
    }
    public boolean postojiUKvizPitanje(Kviz kviz, Pitanje pitanje){
        String query = "SELECT * "+
                "FROM "+DATABASE_TABLE_KVIZ_PITANJE+
                " WHERE "+KVIZ_PITANJE_IDKVIZA+" = '"+kviz.getNaziv()+"' AND "+
                KVIZ_PITANJE_IDPITANJA+" = '"+pitanje.getNaziv()+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.getCount() > 0)
        {
            return true;
        }

        cursor.close();

        return false;
    }
    public void dodajUKvizPitanje(Kviz kviz, Pitanje pitanje){

            if(!postojiUKvizPitanje(kviz, pitanje))
            {
                ContentValues contentValues = new ContentValues();
                contentValues.put(KVIZ_PITANJE_IDKVIZA, kviz.getNaziv());
                contentValues.put(KVIZ_PITANJE_IDPITANJA, pitanje.getNaziv());

                SQLiteDatabase db = this.getWritableDatabase();
                db.insert(DATABASE_TABLE_KVIZ_PITANJE, null, contentValues);
            }
    }
    public boolean postojiUOdgovorPitanje(Pitanje pitanje, String odgovor){
        String query = "SELECT * "+
                "FROM "+DATABASE_TABLE_ODGOVOR_PITANJE+
                " WHERE "+ODGOVOR_PITANJE_IDODGOVORA+" = '"+odgovor+"' AND "+
                ODGOVOR_PITANJE_IDPITANJA+" = '"+pitanje.getNaziv()+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.getCount() > 0)
        {
            return true;
        }

        cursor.close();

        return false;
    }
    public void dodajUOdgovorPitanje(Pitanje pitanje, String odgovor){
        if(!postojiUOdgovorPitanje(pitanje, odgovor))
        {
            ContentValues contentValues = new ContentValues();
            contentValues.put(ODGOVOR_PITANJE_IDODGOVORA, odgovor);
            contentValues.put(ODGOVOR_PITANJE_IDPITANJA, pitanje.getNaziv());

            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DATABASE_TABLE_ODGOVOR_PITANJE, null, contentValues);
        }
    }
    public void editujKviz(Kviz stari, Kviz novi){

        ContentValues editValues = new ContentValues();

        //prvo u bazu ubacim sve kategorije, pa onda kvizove(sa pitanjima u njima)
        editValues.put(KVIZ_ID, novi.getNaziv());
        editValues.put(KVIZ_IDKATEGORIJE, novi.getKategorija().getNaziv());

        //treba pobrisati sve iz zajednicke tabele(kviz_pitanje) pa opet dodati
        for(int i=0;i<stari.getPitanja().size();i++){
            String where = KVIZ_PITANJE_IDPITANJA + " = '" + stari.getPitanja().get(i).getNaziv() + "';";
            String whereArgs[] = null;
            SQLiteDatabase db = this.getWritableDatabase();
            db.delete(DATABASE_TABLE_KVIZ_PITANJE, where, whereArgs);
        }
        for(int i=0; i<novi.getPitanja().size(); i++)
        {
            dodajPitanje(novi.getPitanja().get(i));
            dodajUKvizPitanje(novi, novi.getPitanja().get(i));
        }

        String where = KVIZ_ID + " = '" + stari.getNaziv() + "';";
        String whereArgs[] = null;

        SQLiteDatabase db = this.getWritableDatabase();
        db.update(DATABASE_TABLE_KVIZOVI, editValues, where, whereArgs);
    }
    public void azurirajBazuKategorije(){
        for(int i=0;i<kategorije.size();i++){
            dodajKategoriju(kategorije.get(i));
        }
    }
    public void azurirajBazuKvizovi(){
        for(int i=0;i<kvizovi.size();i++){
            dodajKviz(kvizovi.get(i));
        }
    }
    public ArrayList<Kategorija> ucitajKategorije(){

        ArrayList<Kategorija> sveKategorije = new ArrayList<>();
        String[] kolone = new String[]{KATEGORIJA_ID, KATEGORIJA_IDIKONICE};
        String whereUslov = null;
        String whereArgs[] = null;
        String groupBy = null;
        String having = null;
        String orderBy = null;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(DATABASE_TABLE_KATEGORIJE, kolone, whereUslov, whereArgs, groupBy, having, orderBy);

        int INDEX_KOLONE_KATEGORIJA_ID = cursor.getColumnIndexOrThrow(KATEGORIJA_ID);
        int INDEX_KOLONE_KATEGORIJA_IDIKONICE = cursor.getColumnIndexOrThrow(KATEGORIJA_IDIKONICE);

        while(cursor.moveToNext())
        {
            Kategorija nova = new Kategorija();
            nova.setNaziv(cursor.getString(INDEX_KOLONE_KATEGORIJA_ID));
            nova.setId(cursor.getString(INDEX_KOLONE_KATEGORIJA_IDIKONICE));

            sveKategorije.add(nova);
        }

        cursor.close();

        return sveKategorije;
    }
    //odavde kurslus
    public ArrayList<String> ucitajOdgovore(String naziv){

        ArrayList<String> odgovoriNaPitanje = new ArrayList<>();

        String query = "SELECT * "+
                "FROM "+ DATABASE_TABLE_ODGOVOR_PITANJE +
                " WHERE " + ODGOVOR_PITANJE_IDPITANJA + " = '" + naziv +"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        int INDEX_KOLONE_ODGOVOR = cursor.getColumnIndexOrThrow(ODGOVOR_PITANJE_IDODGOVORA);

        while(cursor.moveToNext())
        {
            odgovoriNaPitanje.add(cursor.getString(INDEX_KOLONE_ODGOVOR));
        }

        cursor.close();

        return odgovoriNaPitanje;
    }
    public ArrayList<Pitanje> ucitajPitanja(Kviz kviz){

        ArrayList<Pitanje> pitanjaUKvizu = new ArrayList<>();

        String query = "SELECT * "+
                "FROM "+ DATABASE_TABLE_KVIZ_PITANJE +
                " WHERE " + KVIZ_PITANJE_IDKVIZA + " = '" + kviz.getNaziv() +"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        int INDEX_KOLONE_PITANJE = cursor.getColumnIndexOrThrow(KVIZ_PITANJE_IDPITANJA);

        while(cursor.moveToNext())
        {
            pitanjaUKvizu.add(dajPitanje(cursor.getString(INDEX_KOLONE_PITANJE)));
        }

        cursor.close();

        return pitanjaUKvizu;
    }
    public Pitanje dajPitanje(String naziv){

        Pitanje pitanje = new Pitanje();
        pitanje.setNaziv(naziv);
        pitanje.setOdgovori(ucitajOdgovore(naziv));
        pitanje.setTekstPitanja(naziv);

        String query = "SELECT * "+
                " FROM "+DATABASE_TABLE_PITANJA+
                " WHERE " + PITANJE_ID + " = '" + naziv + "';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        int INDEX_KOLONE_PITANJE_TACANODGOVOR = cursor.getColumnIndexOrThrow(PITANJE_TACANODGOVOR);

        while(cursor.moveToNext())
        {
            pitanje.setTacan(cursor.getString(INDEX_KOLONE_PITANJE_TACANODGOVOR));
        }

        cursor.close();
        return pitanje;
    }
    public ArrayList<Kviz> ucitajKvizove(){

        ArrayList<Kviz> sviKvizovi = new ArrayList<>();
        String[] kolone = new String[]{KVIZ_ID, KVIZ_IDKATEGORIJE};
        String whereUslov = null;
        String whereArgs[] = null;
        String groupBy = null;
        String having = null;
        String orderBy = null;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(DATABASE_TABLE_KVIZOVI, kolone, whereUslov, whereArgs, groupBy, having, orderBy);

        int INDEX_KOLONE_KVIZ_ID = cursor.getColumnIndexOrThrow(KVIZ_ID);
        int INDEX_KOLONE_KVIZ_IDKATEGORIJE = cursor.getColumnIndexOrThrow(KVIZ_IDKATEGORIJE);

        while(cursor.moveToNext())
        {
            Kviz novi = new Kviz();
            novi.setNaziv(cursor.getString(INDEX_KOLONE_KVIZ_ID));
            novi.setKategorija(dajKategoriju(cursor.getString(INDEX_KOLONE_KVIZ_IDKATEGORIJE)));
            novi.setPitanja(ucitajPitanja(novi));

            sviKvizovi.add(novi);
        }

        cursor.close();

        return sviKvizovi;
    }
    public Kategorija dajKategoriju(String naziv){

        Kategorija kategorija = new Kategorija();
        kategorija.setNaziv(naziv);

        String query = "SELECT * "+
                " FROM "+DATABASE_TABLE_KATEGORIJE+
                " WHERE "+KATEGORIJA_ID+" = '"+naziv+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        int INDEX_KOLONE_KATEGORIJA_IDIKONICE = cursor.getColumnIndexOrThrow(KATEGORIJA_IDIKONICE);

        while(cursor.moveToNext())
        {
            kategorija.setId(cursor.getString(INDEX_KOLONE_KATEGORIJA_IDIKONICE));
        }

        cursor.close();

        return kategorija;
    }
    public void dodajRezultat(String kviz, String igrac, double rezultat)
    {
        if(!postojiRezultat(kviz, igrac, rezultat))
        {
            ContentValues contentValues = new ContentValues();

            contentValues.put(RANGLISTA_IDKVIZA, kviz);
            contentValues.put(RANGLISTA_REZULTAT, rezultat);
            contentValues.put(RANGLISTA_IGRAC, igrac);

            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DATABASE_TABLE_RANGLISTE, null, contentValues);

        }
    }

    private boolean postojiRezultat(String kviz, String igrac, double rezultat) {

        String query = "SELECT * "+
                "FROM "+DATABASE_TABLE_RANGLISTE+
                " WHERE "+RANGLISTA_IDKVIZA+"='" + kviz + "' AND "+RANGLISTA_REZULTAT+" = " + rezultat +" AND "+
                RANGLISTA_IGRAC + " = '" + igrac + "';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.getCount() > 0)
        {
            return true;
        }

        cursor.close();

        return false;
    }
    public ArrayList<String> dajRangListu(String kviz){

        ArrayList<String> rangLista = new ArrayList<>();

        String query = "SELECT * FROM "+
                DATABASE_TABLE_RANGLISTE + " WHERE " + RANGLISTA_IDKVIZA + " = '" + kviz + "';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        int INDEX_KOLONE_RANGLISTA_REZULTAT = cursor.getColumnIndexOrThrow(RANGLISTA_REZULTAT);
        int INDEX_KOLONE_RANGLISTA_IDKVIZA = cursor.getColumnIndexOrThrow(RANGLISTA_IDKVIZA);
        int INDEX_KOLONE_RANGLISTA_IGRAC = cursor.getColumnIndexOrThrow(RANGLISTA_IGRAC);

        ArrayList<Pair<String, Double>> listaParova = new ArrayList<>();

        while(cursor.moveToNext())
        {
            listaParova.add(new Pair<String, Double>(cursor.getString(INDEX_KOLONE_RANGLISTA_IGRAC),cursor.getDouble(INDEX_KOLONE_RANGLISTA_REZULTAT)));
        }

        Collections.sort(listaParova, new Comparator<Pair<String, Double>>() {
            @Override
            public int compare(Pair<String, Double> stringDoublePair, Pair<String, Double> t1) {
                if(stringDoublePair.second > t1.second) return 1;
                else if(stringDoublePair.second < t1.second) return -1;
                return 0;
            }
        });

        for(int i = 0;i<listaParova.size();i++){
            rangLista.add(String.valueOf(i+1) + ". " + listaParova.get(listaParova.size()-1-i).first + " " + String.valueOf(listaParova.get(listaParova.size()-1-i).second));
        }

        cursor.close();

        return rangLista;
    }
    public ArrayList<RangLista> dajRangListe(){

        ArrayList<RangLista> rangLista = new ArrayList<>();

        String query = "SELECT * FROM "+ DATABASE_TABLE_RANGLISTE + ";";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        int INDEX_KOLONE_RANGLISTA_REZULTAT = cursor.getColumnIndexOrThrow(RANGLISTA_REZULTAT);
        int INDEX_KOLONE_RANGLISTA_IDKVIZA = cursor.getColumnIndexOrThrow(RANGLISTA_IDKVIZA);
        int INDEX_KOLONE_RANGLISTA_IGRAC = cursor.getColumnIndexOrThrow(RANGLISTA_IGRAC);

        while(cursor.moveToNext())
        {
            rangLista.add(new RangLista(cursor.getString(INDEX_KOLONE_RANGLISTA_IDKVIZA), cursor.getString(INDEX_KOLONE_RANGLISTA_IGRAC), cursor.getDouble(INDEX_KOLONE_RANGLISTA_REZULTAT)));
        }

        Collections.sort(rangLista, new Comparator<RangLista>() {
            @Override
            public int compare(RangLista ranglista, RangLista t1) {
                if(ranglista.rezultat > t1.rezultat) return 1;
                else if(ranglista.rezultat < t1.rezultat) return -1;
                return 0;
            }
        });

        cursor.close();

        return rangLista;
    }
    public void closeDatabase()
    {
        SQLiteDatabase db = this.getReadableDatabase();

        if (db != null && db.isOpen())
            db.close();
    }
    public void obrisiSve(){
        onUpgrade(this.getWritableDatabase(),0,0);
    }
}
