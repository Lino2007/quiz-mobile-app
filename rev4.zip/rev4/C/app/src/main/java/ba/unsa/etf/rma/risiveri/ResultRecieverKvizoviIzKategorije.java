package ba.unsa.etf.rma.risiveri;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

public class ResultRecieverKvizoviIzKategorije extends ResultReceiver {
    private ReceiverKvizovi mReceiver;
    public ResultRecieverKvizoviIzKategorije(Handler handler) {
        super(handler);
    }
    public void setReceiver(ReceiverKvizovi receiver) {
        mReceiver = receiver;
    }
    /* Deklaracija interfejsa koji će se trebati implementirati */
    public interface ReceiverKvizovi {
        public void onReceiveResultKvizovi(int resultCode, Bundle resultData);
    }
    @Override
    protected void onReceiveResult(int resultCode, Bundle resultData) {
        if (mReceiver != null) {
            mReceiver.onReceiveResultKvizovi(resultCode, resultData);
        }
    }
}
