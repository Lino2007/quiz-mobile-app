package ba.unsa.etf.rma.risiveri;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

public class ResultReceiverPitanje extends ResultReceiver {

    private ReceiverPitanje mReceiver;
    public ResultReceiverPitanje(Handler handler) {
        super(handler);
    }
    public void setReceiver(ReceiverPitanje receiver) {
        mReceiver = receiver;
    }
    /* Deklaracija interfejsa koji će se trebati implementirati */
    public interface ReceiverPitanje {
        public void onReceiveResultPitanje(int resultCode, Bundle resultData);
    }
    @Override
    protected void onReceiveResult(int resultCode, Bundle resultData) {
        if (mReceiver != null) {
            mReceiver.onReceiveResultPitanje(resultCode, resultData);
        }
    }
}
