package ba.unsa.etf.rma.fragmenti;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.KategorijeAdapter;
import ba.unsa.etf.rma.risiveri.ResultRecieverKategorije;
import ba.unsa.etf.rma.servisi.KategorijeServis;
import ba.unsa.etf.rma.servisi.MogucaPitanjaServis;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kategorije;

public class ListaFrag extends Fragment implements ResultRecieverKategorije.Receiver{

    KategorijeAdapter adapter;

    private OnItemClick oic;

    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {

        return inflater.inflate(R.layout.lista_frag, container, false);
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ListView lv = (ListView)getView().findViewById(R.id.listaKategorija);

        if(imaLiInterneta()) {
            Intent kategorijeIntent = new Intent(Intent.ACTION_SYNC, null, getActivity(), KategorijeServis.class);
            ResultRecieverKategorije risiver = new ResultRecieverKategorije(new Handler());
            risiver.setReceiver(ListaFrag.this);
            kategorijeIntent.putExtra("RISIVER", risiver);
            getActivity().startService(kategorijeIntent);
        }

            adapter = new KategorijeAdapter(getActivity(),kategorije);
            lv.setAdapter(adapter);
        try {
            oic = (OnItemClick)getActivity();
        } catch (ClassCastException e) {

            throw new ClassCastException(getActivity().toString() + "Treba implementirati OnItemClick");
        }
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                oic.onItemClicked(position);
            }
        });
    }
    public interface OnItemClick {
        public void onItemClicked(int pos);
    }
    @Override
    public void onReceiveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case KategorijeServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case KategorijeServis.STATUS_FINISHED:
                /* Dohvatanje rezultata i update UI */
                kategorije.clear();
                kategorije.addAll(resultData.<Kategorija>getParcelableArrayList("KATEGORIJE"));
                adapter.notifyDataSetChanged();
                break;
            case KategorijeServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(getActivity(), error, Toast.LENGTH_LONG).show();
                break;
        }
    }
    public boolean imaLiInterneta(){

        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        return netInfo != null && netInfo.isConnected();
    }
}
