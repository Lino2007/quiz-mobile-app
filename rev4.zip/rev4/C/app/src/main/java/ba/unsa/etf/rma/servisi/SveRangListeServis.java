package ba.unsa.etf.rma.servisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.ResultReceiver;
import android.util.Log;
import android.util.Pair;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Konverzija;
import ba.unsa.etf.rma.klase.RangLista;

public class SveRangListeServis extends IntentService {

    public SveRangListeServis()
    {
        super(null);
    }

    public SveRangListeServis(String name)
    {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }
    @Override
    protected void onHandleIntent(Intent intent){

        ArrayList<RangLista> rangListas = intent.getParcelableArrayListExtra("LISTA");

        try{
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();
            Log.d("TOKEN", TOKEN);

            URL urlObj;
            HttpURLConnection urlConnection;

            ArrayList<String> rangListaKviz = new ArrayList<>();
            for(int i=0;i<rangListas.size();i++){
                if(!rangListaKviz.contains(rangListas.get(i).getKviz()))
                rangListaKviz.add(rangListas.get(i).getKviz());
            }

            for(int i=0;i<rangListaKviz.size();i++){
                ArrayList<Pair<String,Double>> listaParova = new ArrayList<>();
                for(int j=0;j<rangListas.size();j++){
                    if(rangListas.get(j).getKviz().equals(rangListaKviz.get(i))){
                        listaParova.add(new Pair<>(rangListas.get(j).getIgrac(), rangListas.get(j).getRezultat()));
                    }
                }
                try{
                    String urlDohvatanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Rangliste/" + URLEncoder.encode(rangListaKviz.get(i)) + "?access_token=";
                    urlObj = new URL(urlDohvatanje + URLEncoder.encode(TOKEN, "UTF-8"));
                    urlConnection = (HttpURLConnection) urlObj.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.setRequestProperty("Content-Type", "application/json");
                    urlConnection.setRequestProperty("Accept", "application/json");

                    InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                    String rezultat = Konverzija.convertStreamToString(in);
                    Log.d("REZULTAT", rezultat);
                    JSONObject jo = new JSONObject(rezultat);

                    Log.d("RangLista", "POSTOJI");

                    try
                    {
                        String urlUpdate = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Rangliste/" + URLEncoder.encode(rangListaKviz.get(i)) + "?currentDocument.exists=true&access_token=";
                        urlObj = new URL(urlUpdate + URLEncoder.encode(TOKEN,"UTF-8"));
                        urlConnection = (HttpURLConnection) urlObj.openConnection();
                        urlConnection.setRequestMethod("PATCH");
                        urlConnection.setRequestProperty("Content-Type", "application/json");
                        urlConnection.setRequestProperty("Accept", "application/json");


                        StringBuilder dokument = new StringBuilder("{ \"fields\": " +
                                "{ \"nazivKviza\": { \"stringValue\": \"" + rangListaKviz.get(i) + "\"}, " +
                                " \"lista\" : { \"mapValue\" : { \"fields\" : { ");
                        int pozicija = 1;
                        for(int j = listaParova.size()-1; j>=0; j--)
                        {
                            dokument.append(" \"" + pozicija + "\" : { \"mapValue\" : { \"fields\" : { " +
                                    " \"" + listaParova.get(j).first + "\" : { \"doubleValue\" : \"" + listaParova.get(j).second + "\"}}}}");

                            if(j != 0)
                                dokument.append(", ");

                            pozicija++;
                        }
                        dokument.append(" }}}}}");

                        OutputStream outputStream = urlConnection.getOutputStream();
                        byte[] unos = dokument.toString().getBytes();
                        outputStream.write(unos, 0, unos.length);

                        InputStream odgovor = urlConnection.getInputStream();
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while((responseLine = bufferedReader.readLine()) != null)
                            response.append(responseLine.trim());

                        Log.d("ODGOVOR", response.toString());
                    }
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                }
                catch(JSONException | FileNotFoundException e){
                    e.printStackTrace();
                    String urlUploadanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Rangliste?documentId=" + URLEncoder.encode(rangListaKviz.get(i)) + "&access_token=";
                    urlObj = new URL(urlUploadanje + URLEncoder.encode(TOKEN,"UTF-8"));
                    urlConnection = (HttpURLConnection) urlObj.openConnection();
                    urlConnection.setDoOutput(true);
                    urlConnection.setRequestMethod("POST");
                    urlConnection.setRequestProperty("Content-Type", "application/json");
                    urlConnection.setRequestProperty("Accept", "application/json");

                    StringBuilder dokument = new StringBuilder("{ \"fields\": " +
                            "{ \"nazivKviza\": { \"stringValue\": \"" + rangListaKviz.get(i) + "\"}, " +
                            " \"lista\" : { \"mapValue\" : { \"fields\" : { ");
                    int pozicija = 1;
                    for(int j = listaParova.size()-1; j>=0; j--)
                    {
                        dokument.append(" \"" + pozicija + "\" : { \"mapValue\" : { \"fields\" : { " +
                                " \"" + listaParova.get(j).first + "\" : { \"doubleValue\" : \"" + listaParova.get(j).second + "\"}}}}");

                        if(j != 0)
                            dokument.append(", ");

                        pozicija++;
                    }
                    dokument.append(" }}}}}");

                    try(OutputStream os = urlConnection.getOutputStream()){
                        byte[] input = dokument.toString().getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }
                    int code = urlConnection.getResponseCode();
                    InputStream odgovor = urlConnection.getInputStream();
                    try(BufferedReader br = new BufferedReader(
                            new InputStreamReader(odgovor, "utf-8"))){
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while((responseLine = br.readLine()) != null){
                            response.append(responseLine.trim());
                        }
                        Log.d("ODGOVOR", response.toString());
                    }
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }

    }
}
