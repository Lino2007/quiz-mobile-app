package ba.unsa.etf.rma.servisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Konverzija;

public class KategorijaServis extends IntentService {

    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;
    Bundle bundle = new Bundle();

    public KategorijaServis() {
        super(null);
    }
    public KategorijaServis(String name) {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }
    @Override
    public void onCreate() {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }
    @Override
    protected void onHandleIntent(Intent intent) {

        final ResultReceiver resultReceiver = intent.getParcelableExtra("RISIVER");
        Kategorija kategorija = intent.getParcelableExtra("KATEGORIJA");

        try {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();
            Log.d("TOKEN", TOKEN);

            URL urlObj;
            HttpURLConnection urlConnection;
            String nazivKategorije = URLEncoder.encode(kategorija.getNaziv(),"utf-8");

            try{
                String urlDohvatanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kategorije/" + nazivKategorije + "?access_token=";
                urlObj = new URL(urlDohvatanje + URLEncoder.encode(TOKEN, "UTF-8"));
                urlConnection = (HttpURLConnection) urlObj.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.setRequestProperty("Accept", "application/json");

                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = Konverzija.convertStreamToString(in);
                JSONObject jo = new JSONObject(rezultat);

                Log.d("KATEGORIJA", rezultat);
                JSONObject polja = jo.getJSONObject("fields");
                JSONObject nazivHelp = polja.getJSONObject("naziv");
                String naziv = nazivHelp.getString("stringValue");
                JSONObject idIkoniceHelp = polja.getJSONObject("idIkonice");
                int idIkonice = idIkoniceHelp.getInt("integerValue");

                kategorija.setNaziv(naziv);
                kategorija.setId(String.valueOf(idIkonice));
                bundle.putString("AlertDialog","");

            }
            catch (FileNotFoundException | JSONException e){
                String urlUploadanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kategorije?documentId=" + nazivKategorije + "&access_token=";
                urlObj = new URL(urlUploadanje + URLEncoder.encode(TOKEN,"UTF-8"));
                urlConnection = (HttpURLConnection) urlObj.openConnection();
                urlConnection.setDoOutput(true);
                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.setRequestProperty("Accept", "application/json");

                String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\": \"" + kategorija.getNaziv() + "\"}, \"idIkonice\": {\"integerValue\": \"" + kategorija.getId() + "\"}}}";
                try(OutputStream os = urlConnection.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                int code = urlConnection.getResponseCode();
                InputStream odgovor = urlConnection.getInputStream();
                try(BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }
            }

            bundle.putParcelable("KATEGORIJA", kategorija);
            resultReceiver.send(STATUS_FINISHED,bundle);

        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}
