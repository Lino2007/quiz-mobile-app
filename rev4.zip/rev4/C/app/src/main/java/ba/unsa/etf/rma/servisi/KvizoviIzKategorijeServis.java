package ba.unsa.etf.rma.servisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Konverzija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizoviIzKategorijeServis extends IntentService {

    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;

    URL urlObj;
    HttpURLConnection urlConnection;
    String TOKEN;

    public KvizoviIzKategorijeServis() {
        super(null);
    }
    public KvizoviIzKategorijeServis(String name) {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }
    @Override
    public void onCreate() {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }
    @Override
    protected void onHandleIntent(Intent intent) {
        final ResultReceiver resultReceiver = intent.getParcelableExtra("RISIVER");
        ArrayList<Kviz> odabrani = new ArrayList<>();
        Kategorija kategorija = intent.getParcelableExtra("KATEGORIJA");

        try {
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
            Log.d("TOKEN", TOKEN);

            String query = "{\n" +
                    "\"structuredQuery\": {\n" +
                    "\"where\": {\n" +
                    "\"fieldFilter\": {\n" +
                    "\"field\": {\"fieldPath\": \"idKategorije\"}, \n" +
                    "\"op\": \"EQUAL\",\n" +
                    "\"value\": {\"stringValue\": \"" + kategorija.getNaziv() + "\"}\n" +
                    "}\n" +
                    "},\n" +
                    "\"select\": {\"fields\": [ {\"fieldPath\": \"idKategorije\"}, {\"fieldPath\": \"naziv\"}, {\"fieldPath\": \"pitanja\"} ] }, \n" +
                    "\"from\": [{\"collectionId\" : \"Kvizovi\"}], \n" +
                    "\"limit\" : 1000\n" +
                    "}\n" +
                    "}";

            String urlDohvatanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents:runQuery?access_token=";
            urlObj = new URL(urlDohvatanje + URLEncoder.encode(TOKEN, "UTF-8"));
            urlConnection = (HttpURLConnection) urlObj.openConnection();
            urlConnection.setDoInput(true);
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("Accept", "application/json");

            try (OutputStream os = urlConnection.getOutputStream()) {
                byte[] input = query.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String rezultat = Konverzija.convertStreamToString(in);
            rezultat = "{\"documents\": " + rezultat + "}";

            Log.d("REZULTAT", rezultat);
            JSONObject jo = new JSONObject(rezultat);

            boolean nemaKvizova = false;
            JSONArray documents = jo.getJSONArray("documents");
                for (int i = 0; i < documents.length(); i++) {
                    JSONObject document = documents.getJSONObject(i);
                    JSONObject kvizHelp = new JSONObject();
                    try {
                        kvizHelp = document.getJSONObject("document");
                    }
                    catch (JSONException e){
                        Bundle bundle = new Bundle();
                        bundle.putParcelableArrayList("KVIZOVI", odabrani);
                        resultReceiver.send(STATUS_FINISHED,bundle);
                        return;
                    }
                    JSONObject polja = kvizHelp.getJSONObject("fields");
                    JSONObject nazivHelp = polja.getJSONObject("naziv");
                    String naziv = nazivHelp.getString("stringValue");
                    JSONObject pitanjaHelp = polja.getJSONObject("pitanja");
                    JSONObject pitanjaHelp1 = pitanjaHelp.getJSONObject("arrayValue");
                    ArrayList<String> naziviPitanja = new ArrayList<>();
                    ArrayList<Pitanje> pitanja;
                    try {
                        JSONArray pitanjaHelp2 = pitanjaHelp1.getJSONArray("values");
                        for (int j = 0; j < pitanjaHelp2.length(); j++) {
                            naziviPitanja.add(pitanjaHelp2.getJSONObject(j).getString("stringValue"));
                        }
                        pitanja = dajPitanja(naziviPitanja);
                    } catch (JSONException e) {
                        pitanja = new ArrayList<>();
                    }
                    Kviz kviz = new Kviz();
                    kviz.setNaziv(naziv);
                    kviz.setPitanja(pitanja);
                    kviz.setKategorija(kategorija);
                    odabrani.add(kviz);
                }
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("KVIZOVI", odabrani);
            resultReceiver.send(STATUS_FINISHED,bundle);
        }
        catch (IOException | JSONException e){
            e.printStackTrace();
        }
    }
    public ArrayList<Pitanje> dajPitanja(ArrayList<String> pitanja){

        ArrayList<Pitanje> pitanjaIzKviza = new ArrayList<>();

            try{
                String urlPitanja = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Pitanja?access_token=";
                urlObj = new URL(urlPitanja + URLEncoder.encode(TOKEN, "UTF-8"));
                urlConnection = (HttpURLConnection) urlObj.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.setRequestProperty("Accept", "application/json");

                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = Konverzija.convertStreamToString(in);
                //Log.d("dokumenti",rezultat);
                JSONObject jo = new JSONObject(rezultat);

                JSONArray documents = jo.getJSONArray("documents");
                for(int i=0;i<documents.length();i++){
                    JSONObject dokument = documents.getJSONObject(i);
                    JSONObject fields = dokument.getJSONObject("fields");
                    JSONObject nazivHelp = fields.getJSONObject("naziv");
                    String naziv = nazivHelp.getString("stringValue");
                    JSONObject indexTacnogHelp = fields.getJSONObject("indexTacnog");
                    int indexTacnog = indexTacnogHelp.getInt("integerValue");
                    JSONObject odgovoriHelp = fields.getJSONObject("odgovori");
                    JSONObject odgovoriHelp1 = odgovoriHelp.getJSONObject("arrayValue");
                    JSONArray odgovoriHelp2 = odgovoriHelp1.getJSONArray("values");
                    ArrayList<String> odgovori = new ArrayList<>();
                    for (int j = 0; j < odgovoriHelp2.length(); j++) {
                        odgovori.add(odgovoriHelp2.getJSONObject(j).getString("stringValue"));
                    }
                    Pitanje pitanje = new Pitanje();
                    pitanje.setNaziv(naziv);
                    pitanje.setOdgovori(odgovori);
                    pitanje.setTacan(odgovori.get(indexTacnog));
                    pitanje.setTekstPitanja(naziv);
                    if(pitanja.contains(naziv)) pitanjaIzKviza.add(pitanje);
                }
            }
            catch(JSONException | IOException e){
                e.printStackTrace();
            }
        return pitanjaIzKviza;
    }
}
