package ba.unsa.etf.rma.fragmenti;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import ba.unsa.etf.rma.R;

public class InformacijeFrag extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        return inflater.inflate(R.layout.informacije_fragment, container, false);
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getArguments().containsKey("naziv kviza") && getArguments().containsKey("broj tacnih") && getArguments().containsKey("broj preostalih") && getArguments().containsKey("procenat tacnih")){

            TextView nazivKviza = (TextView)getView().findViewById(R.id.infNazivKviza);
            nazivKviza.setText(getArguments().getString("naziv kviza"));
            TextView brojTacnihPitanja = (TextView)getView().findViewById(R.id.infBrojTacnihPitanja);
            brojTacnihPitanja.setText(String.valueOf(getArguments().getInt("broj tacnih")));
            TextView brojPreostalihPitanja = (TextView)getView().findViewById(R.id.infBrojPreostalihPitanja);
            brojPreostalihPitanja.setText(String.valueOf(getArguments().getInt("broj preostalih")));
            TextView procenatTacni = (TextView)getView().findViewById(R.id.infProcenatTacni);
            procenatTacni.setText(String.valueOf(getArguments().getDouble("procenat tacnih")));
            Button kraj = (Button)getView().findViewById(R.id.btnKraj);
            kraj.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getActivity().finish();
                }
            });
        }
    }
}
