package ba.unsa.etf.rma.risiveri;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

public class ResultRecieverSviKvizovi extends ResultReceiver {
    private ReceiverSviKvizovi mReceiver;
    public ResultRecieverSviKvizovi(Handler handler) {
        super(handler);
    }
    public void setReceiver(ReceiverSviKvizovi receiver) {
        mReceiver = receiver;
    }
    /* Deklaracija interfejsa koji će se trebati implementirati */
    public interface ReceiverSviKvizovi {
        public void onReceiveResultSviKvizovi(int resultCode, Bundle resultData);
    }
    @Override
    protected void onReceiveResult(int resultCode, Bundle resultData) {
        if (mReceiver != null) {
            mReceiver.onReceiveResultSviKvizovi(resultCode, resultData);
        }
    }
}
