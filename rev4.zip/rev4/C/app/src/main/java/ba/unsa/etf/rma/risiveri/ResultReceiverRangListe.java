package ba.unsa.etf.rma.risiveri;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

public class ResultReceiverRangListe extends ResultReceiver {
    private ReceiverRangListe mReceiver;
    public ResultReceiverRangListe(Handler handler) {
        super(handler);
    }
    public void setReceiver(ReceiverRangListe receiver) {
        mReceiver = receiver;
    }
    /* Deklaracija interfejsa koji će se trebati implementirati */
    public interface ReceiverRangListe {
        public void onReceiveResultRangListe(int resultCode, Bundle resultData);
    }
    @Override
    protected void onReceiveResult(int resultCode, Bundle resultData) {
        if (mReceiver != null) {
            mReceiver.onReceiveResultRangListe(resultCode, resultData);
        }
    }
}
