package ba.unsa.etf.rma.klase;


import android.content.Context;
import android.database.Cursor;
import android.nfc.cardemulation.HostApduService;
import android.provider.CalendarContract.*;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class CalendarContentResolver{

    Context context;
    public CalendarContentResolver(Context context){
        this.context = context;
    }

    public static final String[] proj =
            new String[]{
                    Events.DTSTART,
                    Events.DTEND};

    public Map<String, String> procitajPodatke(){

        Map<String, String> rezultati = new HashMap<>();

        Cursor cursor = null;
        try{
            cursor = context.getContentResolver().query(Events.CONTENT_URI, proj, null, null, null);
        }
        catch(SecurityException e){
            e.printStackTrace();
        }
        while(cursor.moveToNext()){
            String pocetak = cursor.getString(0);
            String kraj = cursor.getString(1);
            rezultati.put(pocetak, kraj);
        }
        return rezultati;
    }
}
