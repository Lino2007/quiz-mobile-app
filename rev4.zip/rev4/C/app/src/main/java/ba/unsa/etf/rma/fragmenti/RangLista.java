package ba.unsa.etf.rma.fragmenti;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;


import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.klase.SQLBaza;
import ba.unsa.etf.rma.risiveri.ResultReceiverRangLista;
import ba.unsa.etf.rma.servisi.RangListaServis;

public class RangLista extends Fragment implements ResultReceiverRangLista.Receiver{

    ArrayList<String> listaIgraca = new ArrayList<>();
    ArrayAdapter<String> adapter;
    private SQLBaza baza;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        baza = new SQLBaza(getActivity());
        return inflater.inflate(R.layout.samo_listview, container, false);
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getArguments().containsKey("IME") && getArguments().containsKey("PROCENAT") && getArguments().containsKey("KVIZ")) {

            ListView lv = (ListView) getView().findViewById(R.id.lvRangLista);
            adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, listaIgraca);
            lv.setAdapter(adapter);

            ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo netInfo = cm.getActiveNetworkInfo();
            //ovo netinfo==null provjerava jel u airplane modu(pise na netu)
            if(netInfo == null || netInfo.isConnected() == false){
                //nema neta ucitava se iz baze
                baza.dodajRezultat(getArguments().getString("KVIZ"), getArguments().getString("IME"), getArguments().getDouble("PROCENAT"));
                listaIgraca.addAll(baza.dajRangListu(getArguments().getString("KVIZ")));
                adapter.notifyDataSetChanged();
            }
            else{
                //ima neta azurira se firebase i u bazi
                Intent intent = new Intent(Intent.ACTION_SYNC, null, getActivity(), RangListaServis.class);
                ResultReceiverRangLista risiver = new ResultReceiverRangLista(new Handler());
                risiver.setReceiver(RangLista.this);
                intent.putExtra("RISIVER", risiver);
                intent.putExtra("IME", getArguments().getString("IME"));
                intent.putExtra("PROCENAT", getArguments().getDouble("PROCENAT"));
                intent.putExtra("KVIZ", getArguments().getString("KVIZ"));
                getActivity().startService(intent);

                baza.dodajRezultat(getArguments().getString("KVIZ"), getArguments().getString("IME"), getArguments().getDouble("PROCENAT"));
            }
        }
    }

    @Override
    public void onReceiveResultRangLista(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case RangListaServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case RangListaServis.STATUS_FINISHED:
                listaIgraca.addAll(resultData.getStringArrayList("LISTA"));
                adapter.notifyDataSetChanged();
                break;
            case RangListaServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(getActivity(), error, Toast.LENGTH_LONG).show();
                break;
        }
    }
}
