package ba.unsa.etf.rma.fragmenti;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;


import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.GridAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.risiveri.ResultRecieverKvizoviIzKategorije;
import ba.unsa.etf.rma.risiveri.ResultRecieverSviKvizovi;
import ba.unsa.etf.rma.servisi.KvizoviIzKategorijeServis;
import ba.unsa.etf.rma.servisi.KvizoviServis;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kvizovi;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.odabraniKvizovi;


public class DetailFrag extends Fragment implements ResultRecieverKvizoviIzKategorije.ReceiverKvizovi, ResultRecieverSviKvizovi.ReceiverSviKvizovi{
    private Kviz dodajKviz;
    GridAdapter gridAdapter;
    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {

        return inflater.inflate(R.layout.detail_frag, container, false);
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if(getArguments().containsKey("kategorija")) {
            odabraniKvizovi.clear();
            Kategorija izabrana = getArguments().getParcelable("kategorija");

            if(imaLiInterneta()) {
                if (izabrana.getNaziv().equals("Svi")) {
                    Intent kvizoviSviIntent = new Intent(Intent.ACTION_SYNC, null, getActivity(), KvizoviServis.class);
                    ResultRecieverSviKvizovi reciever = new ResultRecieverSviKvizovi(new Handler());
                    reciever.setReceiver(DetailFrag.this);
                    kvizoviSviIntent.putExtra("RISIVER", reciever);
                    getActivity().startService(kvizoviSviIntent);
                } else {
                    Intent kvizoviIntent = new Intent(Intent.ACTION_SYNC, null, getActivity(), KvizoviIzKategorijeServis.class);
                    ResultRecieverKvizoviIzKategorije reciever = new ResultRecieverKvizoviIzKategorije(new Handler());
                    reciever.setReceiver(DetailFrag.this);
                    kvizoviIntent.putExtra("RISIVER", reciever);
                    kvizoviIntent.putExtra("KATEGORIJA", izabrana);
                    getActivity().startService(kvizoviIntent);

                }
            }
            else{
                if (izabrana.getNaziv().equals("Svi")) {
                    odabraniKvizovi.addAll(kvizovi);
                } else {
                    for (int j = 0; j < kvizovi.size(); j++) {
                        if (kvizovi.get(j).getKategorija().equals(izabrana))
                            odabraniKvizovi.add(kvizovi.get(j));
                    }
                }
                dodajKviz = new Kviz();
                dodajKviz.setNaziv("Dodaj kviz");
                odabraniKvizovi.add(dodajKviz);
            }

            GridView gridView = (GridView) getView().findViewById(R.id.gridKvizovi);
            gridAdapter = new GridAdapter(getActivity(), odabraniKvizovi);
            gridView.setAdapter(gridAdapter);

            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    if(i==odabraniKvizovi.size()-1) return;
                    Intent igrajKviz = new Intent(getActivity(), IgrajKvizAkt.class);
                    igrajKviz.putExtra("Pozicija", i);
                    getActivity().startActivity(igrajKviz);
                }
            });
            gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                    //odabraniKvizovi.remove(dodajKviz);
                    if(imaLiInterneta()) {
                        Intent dodajKviz = new Intent(getActivity(), DodajKvizAkt.class);
                        dodajKviz.putExtra("Pozicija", i);
                        getActivity().startActivity(dodajKviz);
                    }
                    return true;
                }
            });
        }
    }

    @Override
    public void onReceiveResultSviKvizovi(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case KvizoviServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case KvizoviServis.STATUS_FINISHED:
                kvizovi.clear();
                kvizovi.addAll(resultData.<Kviz>getParcelableArrayList("KVIZOVI"));
                odabraniKvizovi.addAll(kvizovi);
                dodajKviz = new Kviz();
                dodajKviz.setNaziv("Dodaj kviz");
                odabraniKvizovi.add(dodajKviz);
                gridAdapter.notifyDataSetChanged();
                break;
            case KvizoviServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(getActivity(), error, Toast.LENGTH_LONG).show();
                break;
        }
    }
    @Override
    public void onReceiveResultKvizovi(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case KvizoviIzKategorijeServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case KvizoviIzKategorijeServis.STATUS_FINISHED:
                odabraniKvizovi.addAll(resultData.<Kviz>getParcelableArrayList("KVIZOVI"));
                dodajKviz = new Kviz();
                dodajKviz.setNaziv("Dodaj kviz");
                odabraniKvizovi.add(dodajKviz);
                gridAdapter.notifyDataSetChanged();
                for(int i=0;i<odabraniKvizovi.size();i++){
                    if(!kvizovi.contains(odabraniKvizovi.get(i))) kvizovi.add(odabraniKvizovi.get(i));
                }
                break;
            case KvizoviIzKategorijeServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(getActivity(), error, Toast.LENGTH_LONG).show();
                break;
        }
    }
    public boolean imaLiInterneta(){

        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        return netInfo != null && netInfo.isConnected();
    }
}
