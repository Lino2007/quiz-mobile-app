package ba.unsa.etf.rma.risiveri;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

public class ResultReceiverRangLista extends ResultReceiver {
    private Receiver mReceiver;
    public ResultReceiverRangLista(Handler handler) {
        super(handler);
    }
    public void setReceiver(Receiver receiver) {
        mReceiver = receiver;
    }
    /* Deklaracija interfejsa koji će se trebati implementirati */
    public interface Receiver {
        public void onReceiveResultRangLista(int resultCode, Bundle resultData);
    }
    @Override
    protected void onReceiveResult(int resultCode, Bundle resultData) {
        if (mReceiver != null) {
            mReceiver.onReceiveResultRangLista(resultCode, resultData);
        }
    }
}
